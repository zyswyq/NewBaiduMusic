package com.example.dllo.newbaidumusic.minterface;

/**
 * Created by dllo on 17/2/25.
 */

public interface OnNewRecItemClick {
    void onClick(int position);

}
