package com.example.dllo.newbaidumusic.minterface;

/**
 * Created by dllo on 17/2/22.
 */

public interface OnRecItemClick {
    void onClick(int position);
}
