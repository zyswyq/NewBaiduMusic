package com.example.dllo.newbaidumusic.bean;

import java.util.List;

/**
 * Created by dllo on 17/2/16.
 */

public class CommendBean {

    /**
     * result : {"mix_9":{"error_code":22000,"result":[{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485254161f22fc6976dce78310dbef508b78ef443.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/jilupian/index.html","type":4,"title":"独立纪录片中的中国摇滚乐","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14852538394f058a5b951e40b0d7fd364ac1307189.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/songyuzhe/index.html","type":4,"title":"独家专访宋雨喆","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486970699976fae64387723833c931927f9164e17.jpg","type_id":"354335548","type":0,"title":"声色江湖梦中闻","tip_type":0,"author":""}]},"focus":{"error_code":22000,"result":[{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/nmepre/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","code":"http://music.baidu.com/cms/webview/bigwig/lina/index.html","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","randpic_desc":"厉娜生日粉丝征集"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","randpic_desc":"第59届格莱美最佳爵士演唱专辑"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","code":"365048362","mo_type":5,"type":7,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","randpic_desc":"第6周新歌榜 新年新歌抢先听 春晚成榜单赢家"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","code":"533370111","mo_type":2,"type":2,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","randpic_desc":"爱又爱"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","randpic_desc":"《明星私房歌》之秦俊杰陪你听歌聊故事"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","code":"1198","mo_type":9,"type":12,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","randpic_desc":"第59届格莱美 天后之争阿黛尔成最大赢家"}]},"mix_22":{"error_code":22000,"result":[{"desc":"赵雷","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14853039815a65d461e42ec25c11779195e835ddad.jpg","type_id":"275347355","type":2,"title":"无法长大","tip_type":0,"author":"赵雷"},{"desc":"宇多田光","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609265600c65560203d96022a269af453fb8e4.jpg","type_id":"271948337","type":2,"title":"Fantôme","tip_type":0,"author":"宇多田光"},{"desc":"ZAYN/Taylor Swift","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609313124980270e3e6abec5a57ed362443386.jpg","type_id":"285427064","type":2,"title":"I Don\u2019t Wanna Live Forever (Fifty Shades Darker)","tip_type":0,"author":"ZAYN/Taylor Swift"}]},"show_list":{"error_code":22000,"result":[{"type":"learn","picture_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_142ae6a390ad9fcdf8eeff6a72eac81c.jpg","picture":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_87bcbaf07c958c061d8bad05e1d79b37.jpg","web_url":"http://music.baidu.com/cms/webview/ktv_activity/20161123/"}]},"entry":{"error_code":22000,"result":[{"day":"","title":"歌手","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14639875926652ed7c4988517cab87526f15d8f359.jpg","jump":"2"},{"day":"","title":"歌曲分类","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146398764316d87d01865b91f90a598777b1569fdf.jpg","jump":"1"},{"day":"","title":"电台","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473839849b2fb772ae0ec435c68ffff814134e49d.jpg","jump":"8"},{"day":"","title":"会员专区","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473479784373fcb8805326ee3da6fc7fc3891a81a.jpg","jump":"9"}]},"scene":{"result":{"action":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b3fb43166d224f4a0e1143e30ff790529922d1b1.jpg","scene_name":"一个人","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f636afc379310a55e4d177f7b04543a98226103f.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"10"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/1f178a82b9014a9007da7e4daf773912b21bee5e.jpg","scene_name":"赖床","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/dc54564e9258d109b39702b1d658ccbf6c814db8.jpg","scene_model":"1","scene_desc":"每周总有那么7天不想起床","bgpic_ios":"","scene_id":"21"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/94cad1c8a786c917cd5a64c9cf3d70cf3ac757e0.jpg","scene_name":"在路上","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/b999a9014c086e06604a914805087bf40bd1cbd7.jpg","scene_model":"2","scene_desc":"","bgpic_ios":"","scene_id":"0"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b90e7bec54e736d15a00bff89d504fc2d562692a.jpg","scene_name":"工作","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/77c6a7efce1b9d1617f33262f4deb48f8c5464f9.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"12"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a5c27d1ed21b0ef4d176a9aedbc451da80cb3ea7.jpg","scene_name":"放松","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0b7b02087bf40ad1e3996ee0502c11dfa9ecceb0.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"8"}],"emotion":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/3bf33a87e950352a854306f85543fbf2b2118b1b.jpg","scene_name":"激动","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/5882b2b7d0a20cf4f1ac61dc71094b36acaf99f1.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"34"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/9d82d158ccbf6c810ea60f18ba3eb13532fa40a8.jpg","scene_name":"治愈","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/472309f790529822ffa5a6c0d0ca7bcb0a46d41b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"37"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a1ec08fa513d26974c932aad53fbb2fb4216d8f9.jpg","scene_name":"开心","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f703738da9773912e4621a62ff198618367ae269.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"38"}],"operation":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/faedab64034f78f04fd1977e7f310a55b2191c60.jpg","scene_name":"古风","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/2cf5e0fe9925bc313c5e079a59df8db1cb1370b4.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"157"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/bd3eb13533fa828bd727916efb1f4134970a5a32.jpg","scene_name":"新歌抢鲜听","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9213b07eca8065382359a31190dda144ad348204.jpg","scene_model":"1","scene_desc":"网罗全球最新歌曲","bgpic_ios":"","scene_id":"33"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/18d8bc3eb13533faf2ba9fa3aed3fd1f41345b2a.jpg","scene_name":"网络歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9922720e0cf3d7ca73313874f51fbe096a63a9e8.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"156"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/4a36acaf2edda3cc469cb5ad07e93901203f92c6.jpg","scene_name":"校园歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/a71ea8d3fd1f4134ed57037c221f95cad1c85e4b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"160"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c8ea15ce36d3d539961d09c13d87e950352ab08b.jpg","scene_name":"舒缓","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0824ab18972bd40792add5ff7c899e510fb3094d.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"159"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/dbb44aed2e738bd461c6bebca78b87d6267ff95c.jpg","scene_name":"情人节","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/63d0f703918fa0ecfe25630f219759ee3c6ddbd6.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"155"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c2fdfc039245d6884448bf29a2c27d1ed31b24f0.jpg","scene_name":"经典老歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d058ccbf6c81800a68b98f0cb63533fa828b4757.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"161"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d01373f082025aaff566d3a4fcedab64034f1a0c.jpg","scene_name":"热歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/838ba61ea8d3fd1f55b20f55374e251f95ca5f21.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"162"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/cb8065380cd79123bb1999f9ab345982b3b78045.jpg","scene_name":"小清新","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/80cb39dbb6fd526672003a16ac18972bd407368c.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"158"}],"other":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/377adab44aed2e7364d7a8dc8101a18b87d6fa00.jpg","scene_name":"2000年代","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/aa64034f78f0f736ec9dd4020d55b319ebc41355.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"71"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d009b3de9c82d1582e8bac41860a19d8bc3e4231.jpg","scene_name":"说唱","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/7c1ed21b0ef41bd5b37f6df756da81cb39db3d80.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"63"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b2de9c82d158ccbfe74098ca1fd8bc3eb0354145.jpg","scene_name":"国语","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d439b6003af33a87423e9e19c15c10385343b566.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"42"}]},"error_code":22000,"config":[{"color_other":"","play_color":"","scene_version":0,"desc":"","end_time":0,"start_time":0,"scene_color":"","bgpic":"","bgpic_special":"","button_color":""}]},"mix_5":{"error_code":22000,"result":[{"desc":"陈奕迅/谭咏麟","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487151573609e89ef52919f79cbe35765eee3a62b.jpg","type_id":"315780937","type":5,"title":"明天何其多 歌词版","tip_type":0,"author":"陈奕迅/谭咏麟"},{"desc":"Mariah Carey","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154200fa8d3467ed1c58fce9da787d717883db.jpg","type_id":"315553324","type":5,"title":"I Don't","tip_type":0,"author":"Mariah Carey"},{"desc":"郑秀晶/June One Kim","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871541477c682e00ce7d19c76bc7ff887c3f028c.jpg","type_id":"315797607","type":5,"title":"I Don`t Wanna Love You","tip_type":0,"author":"郑秀晶/June One Kim"},{"desc":"杨乃文","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154248f18c469ed21ad174b382bcdce6103303.jpg","type_id":"315779156","type":5,"title":"如一","tip_type":0,"author":"杨乃文"},{"desc":"卢庚戌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487134051e240959330a4fe6d4018429ab3b2fda5.jpg","type_id":"315798325","type":5,"title":"大鱼","tip_type":0,"author":"卢庚戌"},{"desc":"Emma Stone/Ryan Gosling","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487133178082c0f52c7f63af6c41273d892404bc5.jpg","type_id":"311043659","type":5,"title":"《爱乐之城》主题曲MV《繁星之城》","tip_type":0,"author":"Emma Stone/Ryan Gosling"}]},"mix_1":{"error_code":22000,"result":[{"desc":"田馥甄/井柏然","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871779237e3fa7c4a0ab41c2bea4f54398a26bb9.jpg","type_id":"315749329","type":2,"title":"美女与野兽","tip_type":0,"author":"田馥甄/井柏然"},{"desc":"T榜","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487177568fa610135e0e46d056785d365d007bd80.jpg","type_id":"533391615","type":2,"title":"T榜力量9","tip_type":0,"author":"T榜"},{"desc":"Maroon 5/Future","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138087149c535567086c4410a100f6f3177745.jpg","type_id":"315796013","type":2,"title":"Cold","tip_type":0,"author":"Maroon 5/Future"},{"desc":"by2","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871330475cedc760f8d281b8f82e5742cde17f68.jpg","type_id":"533370111","type":2,"title":"爱又爱","tip_type":0,"author":"by2"},{"desc":"何静/高阿鑫","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871239441647ee7bff0e261faf9d797790b7b423.jpg","type_id":"533369902","type":2,"title":"我想调慢钟表","tip_type":0,"author":"何静/高阿鑫"},{"desc":"张信哲","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487037784283e0e6469604b01c1e75132ab9a0835.jpg","type_id":"533357576","type":2,"title":"夏夜星空海","tip_type":0,"author":"张信哲"}]},"recsong":{"error_code":22000,"result":[{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"我多么羡慕你","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"2087714","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/88405622/88405622.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"手语","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"31891016","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"伴奏/纯音乐,现场","title":"婚前的女人","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"942280","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127498985/127498985.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"你要的未来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"12313517","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127512008/127512008.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"你是否天使","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"284712","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/6766a57edcba8381320640d63148539e/262029352/262029352.jpg","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"孩子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"211934","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/80479BCF66F5FB9C6D1EFD6B8E777FBD/252897647/252897647.jpg@s_0,w_500","author":"黄贯中"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"飞行鱼","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"586322","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/124502286/124502286.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"放飞机","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"23165164","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89209602/89209602.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"哪里都是你","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"32934359","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"走在凌晨的影子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"482446","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A3169CC5C47C5BEF6F1F0468AEE6C83A/252272079/252272079.jpg@s_0,w_500","author":"赵传"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"心结","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"954672","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89788745/89788745.jpg@s_0,w_500","author":"周传雄"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"You Made Me Believe In Magic","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7314210","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/854559BF85BB25FE46CD6CA910AF4389/252488661/252488661.jpg@s_0,w_500","author":"张国荣"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"杂念","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1064626","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/E953C002DF377E6912474C60CA03CCCF/252484140/252484140.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"迷思左岸","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7328899","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/36FB3F07472320CBCE40E5903189A713/252474615/252474615.jpg@s_0,w_500","author":"熊天平"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"今夜你会不会来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7317554","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89844326/89844326.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"三生三世","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"458313","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A627C3592BBD179AFB36D76EB63465B3/252493369/252493369.jpg@s_0,w_500","author":"童安格"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"Alone (Infinite H)","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"120001229","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/120001138/120001138.jpg@s_0,w_500","author":"INFINITE"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"变幻是缘份","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7332393","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/315112CED2A7213F8F0A5A7FD4D33E5E/252785827/252785827.jpg@s_0,w_500","author":"钟镇涛"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"怀念的播音员","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"550768","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/54BD4633EF1E2392C8F2D0736F20A60B/252262549/252262549.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"嘭门","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1564131","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/bdebebacabef0d367fe9e6cfb59f9b17/261985908/261985908.jpg","author":"李克勤"}]},"radio":{"error_code":22000,"result":[{"desc":"都市情感","itemid":"13420598","title":"在那座阴雨的小城里，我从未忘记你-【晨曦微露】","album_id":"12380577","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_9b33d3ec6ac16f4c7997ff0486be1baf.jpg"},{"desc":"都市情感","itemid":"13420721","title":"《好可惜》：感谢你曾出现在我的生活里（主播：秋婉）","album_id":"12545344","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_71cc1564df5da0d614eefd7003fe8fc3.jpg"},{"desc":"都市情感","itemid":"13416365","title":"Vol.209找到自己真正热爱的东西（黎小妖）【时光听得见】","album_id":"13028457","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_e57f0ec830b6fe312c739691f6544df1.jpg"},{"desc":"音乐推荐","itemid":"13416522","title":"中国摇滚十大新歌榜丨一月","album_id":"1437655","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1999c69ffd5c60cca64f24a408998786.jpg"},{"desc":"音乐推荐","itemid":"13416370","title":"第239期：只要你愿意，我会陪你很久 - 明明","album_id":"9697691","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_a6d2a51e5eb0f4891aa76dcca8fe0b33.jpg"},{"desc":"段子笑话","itemid":"13416211","title":"为什么年轻人越来越不喜欢过年","album_id":"1175169","type":"lebo","channelid":"11373547","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_d61a5ce5fc7d9fca0381f90bc319463d.jpg"}]},"new_song":{"error_code":22000,"result":{"pic_500":"http://b.hiphotos.baidu.com/ting/pic/item/a50f4bfbfbedab64bcae572ef136afc378311e7b.jpg","listid":"5126","song_info":[{"song_id":"261812117","title":"二十四小时","pic_premium":"http://qukufile2.qianqian.com/data2/pic/261811991/261811991.jpg@s_0,w_500","author":"陈坤,韩庚,大鹏,吴磊,尹正"},{"song_id":"74109283","title":"灵主不悔《画江湖之灵主》手游暨动漫主题曲","author":"汪苏泷"},{"song_id":"261496612","title":"Protocole","pic_premium":"http://qukufile2.qianqian.com/data2/pic/07a830e962bbb4e58e29842f45d44b66/261496583/261496583.jpg@s_0,w_500","author":"Alpha Wann"}]}},"diy":{"error_code":22000,"result":[{"position":1,"tag":"华语,流行,经典","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/83426ed526f062f75d5474b58dd49a7d.jpg","title":"【环球之音】一人一首华语经典","collectnum":16,"type":"gedan","listenum":10074,"listid":"365052526"},{"position":2,"tag":"华语,民谣","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ba7032ad93e6b764daea97ea571a834a.jpg","title":"民谣歌手以歌行至大江南北","collectnum":14,"type":"gedan","listenum":5288,"listid":"365047946"},{"position":3,"tag":"欧美,RnB/Soul,流行","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a3370926b81187627e3d8b4193c1537b.jpg","title":"前奏沦陷|R&B深情对唱","collectnum":2,"type":"gedan","listenum":1742,"listid":"365048225"},{"position":4,"tag":"欧美,爵士,放松","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b06eda3237fffb4e9958315e9d0cccd2.jpg","title":"【环球之音】Verve爵士经典时刻","collectnum":174,"type":"gedan","listenum":33655,"listid":"364201294"},{"position":5,"tag":"流行,韩语","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ebbcaf4493c16839d3f4adf30f56aa5b.jpg","title":"韩语|爱情有千百种模样","collectnum":4,"type":"gedan","listenum":1317,"listid":"365047559"},{"position":6,"tag":"华语,流行,婚礼","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4873ac5a497caae47af2d77e4b7dfa4a.jpg","title":"浪漫华语，赠予你美妙婚礼","collectnum":37,"type":"gedan","listenum":8651,"listid":"364515713"}]},"mod_7":{"error_code":22000,"result":[{"desc":"百度音乐独家DJ节目《有待咖啡》 | 第三期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487149365bb48e665bb7a91297610328af8db770d.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","type":4,"title":"本届格莱美\u201c最佳爵士乐演唱专辑奖\u201d注定颁给他？","tip_type":0,"author":""},{"desc":"明星私房歌 | 听偶像推荐的歌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870629150d5ac6732b5390b8d56bd646e62d281e.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","type":4,"title":"秦俊杰陪你听歌聊故事","tip_type":0,"author":""},{"desc":"一周音乐热 | 网罗一周乐坛动态！","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870613862ce10bb200beda7a0c2d17cac247c614.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","type":4,"title":"Lady Gaga化身老司机，这车你坐不坐？","tip_type":0,"author":""},{"desc":"郭顶的这张专辑得听一听","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148706176453088e4ce24db5377be08a504614ce51.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/guoding214/","type":4,"title":"一个人的情人节","tip_type":0,"author":""},{"desc":"音乐大人物 | 带给你绝妙的音乐，独特的故事","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486969080b97701a0721f433be0500154b851ae02.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/yydrwdzw/index.html","type":4,"title":"专访大张伟 | 我是一个勤劳能干的人间精品","tip_type":0,"author":""},{"desc":"百度音乐独家DJ节目《在云端》 | 第六期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148671206164196ca7e2128d013214c1b95386514a.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/linhai6/","type":4,"title":"娱乐圈中，每首情歌的背后，都有一段故事","tip_type":0,"author":""},{"desc":"爱豆show | 带你跟进新、热idol的脚步","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485156345f2157eaead005f646104a6521ff2f32f.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/idolshow15/index.html","type":4,"title":"这些对唱So Sweet~","tip_type":0,"author":""},{"desc":"跟着音乐 环球世界 | 第二期  Island","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14848281717f5b2bd029ebb0ddf6561779e1af4226.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activiity/hqisland/index.html","type":4,"title":"一个影响全世界的小岛......","tip_type":0,"author":""},{"desc":"音乐风格馆 | 为你解读各种音乐的魅力","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1480931404b93a37d50116cfaf173e2e09259abbf3.jpg","type_id":"http://music.baidu.com/cms/webview/bigwig/yyfgg_v2/index.html","type":4,"title":"方大同实力解读：新灵魂乐的\u201c前世今生\u201d","tip_type":0,"author":""}]},"king":{"error_code":22000,"result":[{"pic_big":"http://musicdata.baidu.com/data2/pic/750be293f2768372fece0bc0cc3cc40c/299549244/299549244.jpg@s_0,w_150","title":"钢铁森林","author":"冯建宇"},{"pic_big":"http://musicdata.baidu.com/data2/pic/dee57a075da12ee283c6e9ba9dbf9b66/531451362/531451362.jpg@s_0,w_150","title":" Goodbye","author":"2NE1"},{"pic_big":"http://musicdata.baidu.com/data2/pic/522740217/5e43477ce1f6bf34e72595936019f5e2/522740217.jpg@s_0,w_150","title":"极光","author":"郑兴琦"}]}}
     * error_code : 22000
     * module : [{"link_url":"","pos":1,"title":"焦点图","key":"focus","picurl":"","title_more":"","style":1,"jump":""},{"link_url":"","pos":2,"title":"音乐导航","key":"entry","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1463974498ee916568af45b9417191fe7bcce01619.jpg","title_more":"更多","style":13,"jump":"0"},{"link_url":"","pos":3,"title":"每日热点","key":"mix_2","picurl":"","title_more":"","style":3,"jump":""},{"link_url":"","pos":4,"title":"歌单推荐","key":"diy","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146537068808d757527df896d28f62e60b3ad4f277.jpg","title_more":"更多","style":15,"jump":"3"},{"link_url":"","pos":5,"title":"广告图片(大)","key":"ad_big","picurl":"","title_more":"","style":7,"jump":""},{"link_url":"","pos":6,"title":"新碟上架","key":"mix_1","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1465370722dfa35e762ce6c854d656eac195f7fcd5.jpg","title_more":"更多","style":9,"jump":"7"},{"link_url":"","pos":7,"title":"热销专辑","key":"mix_22","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146640780395497fb5d1cc59a4cb81580819fbc07b.jpg","title_more":"更多","style":8,"jump":"24"},{"link_url":"","pos":8,"title":"原商城固定入口（现产品调查问卷）","key":"mod_26","picurl":"","title_more":"","style":4,"jump":""},{"link_url":"","pos":9,"title":"场景电台","key":"scene","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1465370748a3defe2c3bdfa60416d432ea01210b30.jpg","title_more":"更多","style":2,"jump":"6"},{"link_url":"","pos":10,"title":"今日推荐歌曲","key":"recsong","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14653709721f134fb220693dff72cce9f8bae7d1ce.jpg","title_more":"更多","style":10,"jump":"0"},{"link_url":"","pos":11,"title":"原创音乐","key":"mix_9","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1465370987dc19b57e5ee3cb4c5c705aeca66d6dab.jpg","title_more":"","style":8,"jump":""},{"link_url":"","pos":12,"title":"最热MV推荐","key":"mix_5","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14653710033de8c390ee5bc00e31e5ab22793da860.jpg","title_more":"更多","style":9,"jump":"10"},{"link_url":"","pos":13,"title":"乐播节目","key":"radio","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146537101814c89604b4945401f5fc52b9fa2d6ea6.jpg","title_more":"更多","style":14,"jump":"5"},{"link_url":"","pos":14,"title":"专栏","key":"mod_7","picurl":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1465371032678a4863cdc2ceb4ecdf3c8294e81ee4.jpg","title_more":"","style":11,"jump":""},{"link_url":"","pos":15,"title":"广告图片(小)","key":"ad_small","picurl":"","title_more":"","style":6,"jump":""}]
     */

    private ResultBeanXXXXXXXXXXXXXX result;
    private int error_code;
    private List<ModuleBean> module;

    public ResultBeanXXXXXXXXXXXXXX getResult() {
        return result;
    }

    public void setResult(ResultBeanXXXXXXXXXXXXXX result) {
        this.result = result;
    }

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }

    public List<ModuleBean> getModule() {
        return module;
    }

    public void setModule(List<ModuleBean> module) {
        this.module = module;
    }

    public static class ResultBeanXXXXXXXXXXXXXX {
        /**
         * mix_9 : {"error_code":22000,"result":[{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485254161f22fc6976dce78310dbef508b78ef443.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/jilupian/index.html","type":4,"title":"独立纪录片中的中国摇滚乐","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14852538394f058a5b951e40b0d7fd364ac1307189.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/songyuzhe/index.html","type":4,"title":"独家专访宋雨喆","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486970699976fae64387723833c931927f9164e17.jpg","type_id":"354335548","type":0,"title":"声色江湖梦中闻","tip_type":0,"author":""}]}
         * focus : {"error_code":22000,"result":[{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/nmepre/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","code":"http://music.baidu.com/cms/webview/bigwig/lina/index.html","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","randpic_desc":"厉娜生日粉丝征集"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","randpic_desc":"第59届格莱美最佳爵士演唱专辑"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","code":"365048362","mo_type":5,"type":7,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","randpic_desc":"第6周新歌榜 新年新歌抢先听 春晚成榜单赢家"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","code":"533370111","mo_type":2,"type":2,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","randpic_desc":"爱又爱"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","randpic_desc":"《明星私房歌》之秦俊杰陪你听歌聊故事"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","code":"1198","mo_type":9,"type":12,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","randpic_desc":"第59届格莱美 天后之争阿黛尔成最大赢家"}]}
         * mix_22 : {"error_code":22000,"result":[{"desc":"赵雷","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14853039815a65d461e42ec25c11779195e835ddad.jpg","type_id":"275347355","type":2,"title":"无法长大","tip_type":0,"author":"赵雷"},{"desc":"宇多田光","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609265600c65560203d96022a269af453fb8e4.jpg","type_id":"271948337","type":2,"title":"Fantôme","tip_type":0,"author":"宇多田光"},{"desc":"ZAYN/Taylor Swift","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609313124980270e3e6abec5a57ed362443386.jpg","type_id":"285427064","type":2,"title":"I Don\u2019t Wanna Live Forever (Fifty Shades Darker)","tip_type":0,"author":"ZAYN/Taylor Swift"}]}
         * show_list : {"error_code":22000,"result":[{"type":"learn","picture_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_142ae6a390ad9fcdf8eeff6a72eac81c.jpg","picture":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_87bcbaf07c958c061d8bad05e1d79b37.jpg","web_url":"http://music.baidu.com/cms/webview/ktv_activity/20161123/"}]}
         * entry : {"error_code":22000,"result":[{"day":"","title":"歌手","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14639875926652ed7c4988517cab87526f15d8f359.jpg","jump":"2"},{"day":"","title":"歌曲分类","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146398764316d87d01865b91f90a598777b1569fdf.jpg","jump":"1"},{"day":"","title":"电台","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473839849b2fb772ae0ec435c68ffff814134e49d.jpg","jump":"8"},{"day":"","title":"会员专区","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473479784373fcb8805326ee3da6fc7fc3891a81a.jpg","jump":"9"}]}
         * scene : {"result":{"action":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b3fb43166d224f4a0e1143e30ff790529922d1b1.jpg","scene_name":"一个人","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f636afc379310a55e4d177f7b04543a98226103f.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"10"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/1f178a82b9014a9007da7e4daf773912b21bee5e.jpg","scene_name":"赖床","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/dc54564e9258d109b39702b1d658ccbf6c814db8.jpg","scene_model":"1","scene_desc":"每周总有那么7天不想起床","bgpic_ios":"","scene_id":"21"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/94cad1c8a786c917cd5a64c9cf3d70cf3ac757e0.jpg","scene_name":"在路上","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/b999a9014c086e06604a914805087bf40bd1cbd7.jpg","scene_model":"2","scene_desc":"","bgpic_ios":"","scene_id":"0"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b90e7bec54e736d15a00bff89d504fc2d562692a.jpg","scene_name":"工作","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/77c6a7efce1b9d1617f33262f4deb48f8c5464f9.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"12"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a5c27d1ed21b0ef4d176a9aedbc451da80cb3ea7.jpg","scene_name":"放松","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0b7b02087bf40ad1e3996ee0502c11dfa9ecceb0.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"8"}],"emotion":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/3bf33a87e950352a854306f85543fbf2b2118b1b.jpg","scene_name":"激动","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/5882b2b7d0a20cf4f1ac61dc71094b36acaf99f1.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"34"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/9d82d158ccbf6c810ea60f18ba3eb13532fa40a8.jpg","scene_name":"治愈","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/472309f790529822ffa5a6c0d0ca7bcb0a46d41b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"37"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a1ec08fa513d26974c932aad53fbb2fb4216d8f9.jpg","scene_name":"开心","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f703738da9773912e4621a62ff198618367ae269.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"38"}],"operation":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/faedab64034f78f04fd1977e7f310a55b2191c60.jpg","scene_name":"古风","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/2cf5e0fe9925bc313c5e079a59df8db1cb1370b4.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"157"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/bd3eb13533fa828bd727916efb1f4134970a5a32.jpg","scene_name":"新歌抢鲜听","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9213b07eca8065382359a31190dda144ad348204.jpg","scene_model":"1","scene_desc":"网罗全球最新歌曲","bgpic_ios":"","scene_id":"33"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/18d8bc3eb13533faf2ba9fa3aed3fd1f41345b2a.jpg","scene_name":"网络歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9922720e0cf3d7ca73313874f51fbe096a63a9e8.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"156"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/4a36acaf2edda3cc469cb5ad07e93901203f92c6.jpg","scene_name":"校园歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/a71ea8d3fd1f4134ed57037c221f95cad1c85e4b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"160"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c8ea15ce36d3d539961d09c13d87e950352ab08b.jpg","scene_name":"舒缓","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0824ab18972bd40792add5ff7c899e510fb3094d.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"159"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/dbb44aed2e738bd461c6bebca78b87d6267ff95c.jpg","scene_name":"情人节","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/63d0f703918fa0ecfe25630f219759ee3c6ddbd6.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"155"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c2fdfc039245d6884448bf29a2c27d1ed31b24f0.jpg","scene_name":"经典老歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d058ccbf6c81800a68b98f0cb63533fa828b4757.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"161"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d01373f082025aaff566d3a4fcedab64034f1a0c.jpg","scene_name":"热歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/838ba61ea8d3fd1f55b20f55374e251f95ca5f21.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"162"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/cb8065380cd79123bb1999f9ab345982b3b78045.jpg","scene_name":"小清新","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/80cb39dbb6fd526672003a16ac18972bd407368c.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"158"}],"other":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/377adab44aed2e7364d7a8dc8101a18b87d6fa00.jpg","scene_name":"2000年代","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/aa64034f78f0f736ec9dd4020d55b319ebc41355.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"71"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d009b3de9c82d1582e8bac41860a19d8bc3e4231.jpg","scene_name":"说唱","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/7c1ed21b0ef41bd5b37f6df756da81cb39db3d80.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"63"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b2de9c82d158ccbfe74098ca1fd8bc3eb0354145.jpg","scene_name":"国语","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d439b6003af33a87423e9e19c15c10385343b566.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"42"}]},"error_code":22000,"config":[{"color_other":"","play_color":"","scene_version":0,"desc":"","end_time":0,"start_time":0,"scene_color":"","bgpic":"","bgpic_special":"","button_color":""}]}
         * mix_5 : {"error_code":22000,"result":[{"desc":"陈奕迅/谭咏麟","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487151573609e89ef52919f79cbe35765eee3a62b.jpg","type_id":"315780937","type":5,"title":"明天何其多 歌词版","tip_type":0,"author":"陈奕迅/谭咏麟"},{"desc":"Mariah Carey","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154200fa8d3467ed1c58fce9da787d717883db.jpg","type_id":"315553324","type":5,"title":"I Don't","tip_type":0,"author":"Mariah Carey"},{"desc":"郑秀晶/June One Kim","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871541477c682e00ce7d19c76bc7ff887c3f028c.jpg","type_id":"315797607","type":5,"title":"I Don`t Wanna Love You","tip_type":0,"author":"郑秀晶/June One Kim"},{"desc":"杨乃文","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154248f18c469ed21ad174b382bcdce6103303.jpg","type_id":"315779156","type":5,"title":"如一","tip_type":0,"author":"杨乃文"},{"desc":"卢庚戌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487134051e240959330a4fe6d4018429ab3b2fda5.jpg","type_id":"315798325","type":5,"title":"大鱼","tip_type":0,"author":"卢庚戌"},{"desc":"Emma Stone/Ryan Gosling","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487133178082c0f52c7f63af6c41273d892404bc5.jpg","type_id":"311043659","type":5,"title":"《爱乐之城》主题曲MV《繁星之城》","tip_type":0,"author":"Emma Stone/Ryan Gosling"}]}
         * mix_1 : {"error_code":22000,"result":[{"desc":"田馥甄/井柏然","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871779237e3fa7c4a0ab41c2bea4f54398a26bb9.jpg","type_id":"315749329","type":2,"title":"美女与野兽","tip_type":0,"author":"田馥甄/井柏然"},{"desc":"T榜","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487177568fa610135e0e46d056785d365d007bd80.jpg","type_id":"533391615","type":2,"title":"T榜力量9","tip_type":0,"author":"T榜"},{"desc":"Maroon 5/Future","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138087149c535567086c4410a100f6f3177745.jpg","type_id":"315796013","type":2,"title":"Cold","tip_type":0,"author":"Maroon 5/Future"},{"desc":"by2","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871330475cedc760f8d281b8f82e5742cde17f68.jpg","type_id":"533370111","type":2,"title":"爱又爱","tip_type":0,"author":"by2"},{"desc":"何静/高阿鑫","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871239441647ee7bff0e261faf9d797790b7b423.jpg","type_id":"533369902","type":2,"title":"我想调慢钟表","tip_type":0,"author":"何静/高阿鑫"},{"desc":"张信哲","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487037784283e0e6469604b01c1e75132ab9a0835.jpg","type_id":"533357576","type":2,"title":"夏夜星空海","tip_type":0,"author":"张信哲"}]}
         * recsong : {"error_code":22000,"result":[{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"我多么羡慕你","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"2087714","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/88405622/88405622.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"手语","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"31891016","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"伴奏/纯音乐,现场","title":"婚前的女人","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"942280","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127498985/127498985.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"你要的未来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"12313517","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127512008/127512008.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"你是否天使","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"284712","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/6766a57edcba8381320640d63148539e/262029352/262029352.jpg","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"孩子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"211934","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/80479BCF66F5FB9C6D1EFD6B8E777FBD/252897647/252897647.jpg@s_0,w_500","author":"黄贯中"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"飞行鱼","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"586322","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/124502286/124502286.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"放飞机","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"23165164","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89209602/89209602.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"哪里都是你","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"32934359","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"走在凌晨的影子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"482446","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A3169CC5C47C5BEF6F1F0468AEE6C83A/252272079/252272079.jpg@s_0,w_500","author":"赵传"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"心结","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"954672","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89788745/89788745.jpg@s_0,w_500","author":"周传雄"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"You Made Me Believe In Magic","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7314210","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/854559BF85BB25FE46CD6CA910AF4389/252488661/252488661.jpg@s_0,w_500","author":"张国荣"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"杂念","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1064626","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/E953C002DF377E6912474C60CA03CCCF/252484140/252484140.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"迷思左岸","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7328899","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/36FB3F07472320CBCE40E5903189A713/252474615/252474615.jpg@s_0,w_500","author":"熊天平"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"今夜你会不会来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7317554","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89844326/89844326.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"三生三世","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"458313","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A627C3592BBD179AFB36D76EB63465B3/252493369/252493369.jpg@s_0,w_500","author":"童安格"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"Alone (Infinite H)","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"120001229","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/120001138/120001138.jpg@s_0,w_500","author":"INFINITE"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"变幻是缘份","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7332393","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/315112CED2A7213F8F0A5A7FD4D33E5E/252785827/252785827.jpg@s_0,w_500","author":"钟镇涛"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"怀念的播音员","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"550768","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/54BD4633EF1E2392C8F2D0736F20A60B/252262549/252262549.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"嘭门","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1564131","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/bdebebacabef0d367fe9e6cfb59f9b17/261985908/261985908.jpg","author":"李克勤"}]}
         * radio : {"error_code":22000,"result":[{"desc":"都市情感","itemid":"13420598","title":"在那座阴雨的小城里，我从未忘记你-【晨曦微露】","album_id":"12380577","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_9b33d3ec6ac16f4c7997ff0486be1baf.jpg"},{"desc":"都市情感","itemid":"13420721","title":"《好可惜》：感谢你曾出现在我的生活里（主播：秋婉）","album_id":"12545344","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_71cc1564df5da0d614eefd7003fe8fc3.jpg"},{"desc":"都市情感","itemid":"13416365","title":"Vol.209找到自己真正热爱的东西（黎小妖）【时光听得见】","album_id":"13028457","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_e57f0ec830b6fe312c739691f6544df1.jpg"},{"desc":"音乐推荐","itemid":"13416522","title":"中国摇滚十大新歌榜丨一月","album_id":"1437655","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1999c69ffd5c60cca64f24a408998786.jpg"},{"desc":"音乐推荐","itemid":"13416370","title":"第239期：只要你愿意，我会陪你很久 - 明明","album_id":"9697691","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_a6d2a51e5eb0f4891aa76dcca8fe0b33.jpg"},{"desc":"段子笑话","itemid":"13416211","title":"为什么年轻人越来越不喜欢过年","album_id":"1175169","type":"lebo","channelid":"11373547","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_d61a5ce5fc7d9fca0381f90bc319463d.jpg"}]}
         * new_song : {"error_code":22000,"result":{"pic_500":"http://b.hiphotos.baidu.com/ting/pic/item/a50f4bfbfbedab64bcae572ef136afc378311e7b.jpg","listid":"5126","song_info":[{"song_id":"261812117","title":"二十四小时","pic_premium":"http://qukufile2.qianqian.com/data2/pic/261811991/261811991.jpg@s_0,w_500","author":"陈坤,韩庚,大鹏,吴磊,尹正"},{"song_id":"74109283","title":"灵主不悔《画江湖之灵主》手游暨动漫主题曲","author":"汪苏泷"},{"song_id":"261496612","title":"Protocole","pic_premium":"http://qukufile2.qianqian.com/data2/pic/07a830e962bbb4e58e29842f45d44b66/261496583/261496583.jpg@s_0,w_500","author":"Alpha Wann"}]}}
         * diy : {"error_code":22000,"result":[{"position":1,"tag":"华语,流行,经典","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/83426ed526f062f75d5474b58dd49a7d.jpg","title":"【环球之音】一人一首华语经典","collectnum":16,"type":"gedan","listenum":10074,"listid":"365052526"},{"position":2,"tag":"华语,民谣","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ba7032ad93e6b764daea97ea571a834a.jpg","title":"民谣歌手以歌行至大江南北","collectnum":14,"type":"gedan","listenum":5288,"listid":"365047946"},{"position":3,"tag":"欧美,RnB/Soul,流行","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a3370926b81187627e3d8b4193c1537b.jpg","title":"前奏沦陷|R&B深情对唱","collectnum":2,"type":"gedan","listenum":1742,"listid":"365048225"},{"position":4,"tag":"欧美,爵士,放松","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b06eda3237fffb4e9958315e9d0cccd2.jpg","title":"【环球之音】Verve爵士经典时刻","collectnum":174,"type":"gedan","listenum":33655,"listid":"364201294"},{"position":5,"tag":"流行,韩语","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ebbcaf4493c16839d3f4adf30f56aa5b.jpg","title":"韩语|爱情有千百种模样","collectnum":4,"type":"gedan","listenum":1317,"listid":"365047559"},{"position":6,"tag":"华语,流行,婚礼","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4873ac5a497caae47af2d77e4b7dfa4a.jpg","title":"浪漫华语，赠予你美妙婚礼","collectnum":37,"type":"gedan","listenum":8651,"listid":"364515713"}]}
         * mod_7 : {"error_code":22000,"result":[{"desc":"百度音乐独家DJ节目《有待咖啡》 | 第三期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487149365bb48e665bb7a91297610328af8db770d.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","type":4,"title":"本届格莱美\u201c最佳爵士乐演唱专辑奖\u201d注定颁给他？","tip_type":0,"author":""},{"desc":"明星私房歌 | 听偶像推荐的歌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870629150d5ac6732b5390b8d56bd646e62d281e.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","type":4,"title":"秦俊杰陪你听歌聊故事","tip_type":0,"author":""},{"desc":"一周音乐热 | 网罗一周乐坛动态！","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870613862ce10bb200beda7a0c2d17cac247c614.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","type":4,"title":"Lady Gaga化身老司机，这车你坐不坐？","tip_type":0,"author":""},{"desc":"郭顶的这张专辑得听一听","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148706176453088e4ce24db5377be08a504614ce51.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/guoding214/","type":4,"title":"一个人的情人节","tip_type":0,"author":""},{"desc":"音乐大人物 | 带给你绝妙的音乐，独特的故事","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486969080b97701a0721f433be0500154b851ae02.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/yydrwdzw/index.html","type":4,"title":"专访大张伟 | 我是一个勤劳能干的人间精品","tip_type":0,"author":""},{"desc":"百度音乐独家DJ节目《在云端》 | 第六期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148671206164196ca7e2128d013214c1b95386514a.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/linhai6/","type":4,"title":"娱乐圈中，每首情歌的背后，都有一段故事","tip_type":0,"author":""},{"desc":"爱豆show | 带你跟进新、热idol的脚步","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485156345f2157eaead005f646104a6521ff2f32f.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/idolshow15/index.html","type":4,"title":"这些对唱So Sweet~","tip_type":0,"author":""},{"desc":"跟着音乐 环球世界 | 第二期  Island","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14848281717f5b2bd029ebb0ddf6561779e1af4226.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activiity/hqisland/index.html","type":4,"title":"一个影响全世界的小岛......","tip_type":0,"author":""},{"desc":"音乐风格馆 | 为你解读各种音乐的魅力","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1480931404b93a37d50116cfaf173e2e09259abbf3.jpg","type_id":"http://music.baidu.com/cms/webview/bigwig/yyfgg_v2/index.html","type":4,"title":"方大同实力解读：新灵魂乐的\u201c前世今生\u201d","tip_type":0,"author":""}]}
         * king : {"error_code":22000,"result":[{"pic_big":"http://musicdata.baidu.com/data2/pic/750be293f2768372fece0bc0cc3cc40c/299549244/299549244.jpg@s_0,w_150","title":"钢铁森林","author":"冯建宇"},{"pic_big":"http://musicdata.baidu.com/data2/pic/dee57a075da12ee283c6e9ba9dbf9b66/531451362/531451362.jpg@s_0,w_150","title":" Goodbye","author":"2NE1"},{"pic_big":"http://musicdata.baidu.com/data2/pic/522740217/5e43477ce1f6bf34e72595936019f5e2/522740217.jpg@s_0,w_150","title":"极光","author":"郑兴琦"}]}
         */

        private Mix9Bean mix_9;
        private FocusBean focus;
        private Mix22Bean mix_22;
        private ShowListBean show_list;
        private EntryBean entry;
        private SceneBean scene;
        private Mix5Bean mix_5;
        private Mix1Bean mix_1;
        private RecsongBean recsong;
        private RadioBean radio;
        private NewSongBean new_song;
        private DiyBean diy;
        private Mod7Bean mod_7;
        private KingBean king;

        public Mix9Bean getMix_9() {
            return mix_9;
        }

        public void setMix_9(Mix9Bean mix_9) {
            this.mix_9 = mix_9;
        }

        public FocusBean getFocus() {
            return focus;
        }

        public void setFocus(FocusBean focus) {
            this.focus = focus;
        }

        public Mix22Bean getMix_22() {
            return mix_22;
        }

        public void setMix_22(Mix22Bean mix_22) {
            this.mix_22 = mix_22;
        }

        public ShowListBean getShow_list() {
            return show_list;
        }

        public void setShow_list(ShowListBean show_list) {
            this.show_list = show_list;
        }

        public EntryBean getEntry() {
            return entry;
        }

        public void setEntry(EntryBean entry) {
            this.entry = entry;
        }

        public SceneBean getScene() {
            return scene;
        }

        public void setScene(SceneBean scene) {
            this.scene = scene;
        }

        public Mix5Bean getMix_5() {
            return mix_5;
        }

        public void setMix_5(Mix5Bean mix_5) {
            this.mix_5 = mix_5;
        }

        public Mix1Bean getMix_1() {
            return mix_1;
        }

        public void setMix_1(Mix1Bean mix_1) {
            this.mix_1 = mix_1;
        }

        public RecsongBean getRecsong() {
            return recsong;
        }

        public void setRecsong(RecsongBean recsong) {
            this.recsong = recsong;
        }

        public RadioBean getRadio() {
            return radio;
        }

        public void setRadio(RadioBean radio) {
            this.radio = radio;
        }

        public NewSongBean getNew_song() {
            return new_song;
        }

        public void setNew_song(NewSongBean new_song) {
            this.new_song = new_song;
        }

        public DiyBean getDiy() {
            return diy;
        }

        public void setDiy(DiyBean diy) {
            this.diy = diy;
        }

        public Mod7Bean getMod_7() {
            return mod_7;
        }

        public void setMod_7(Mod7Bean mod_7) {
            this.mod_7 = mod_7;
        }

        public KingBean getKing() {
            return king;
        }

        public void setKing(KingBean king) {
            this.king = king;
        }

        public static class Mix9Bean {
            /**
             * error_code : 22000
             * result : [{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485254161f22fc6976dce78310dbef508b78ef443.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/jilupian/index.html","type":4,"title":"独立纪录片中的中国摇滚乐","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14852538394f058a5b951e40b0d7fd364ac1307189.jpg","type_id":"http://y.baidu.com/cms/topic/webapp/2017/songyuzhe/index.html","type":4,"title":"独家专访宋雨喆","tip_type":0,"author":""},{"desc":"","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486970699976fae64387723833c931927f9164e17.jpg","type_id":"354335548","type":0,"title":"声色江湖梦中闻","tip_type":0,"author":""}]
             */

            private int error_code;
            private List<ResultBean> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBean> getResult() {
                return result;
            }

            public void setResult(List<ResultBean> result) {
                this.result = result;
            }

            public static class ResultBean {
                /**
                 * desc :
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485254161f22fc6976dce78310dbef508b78ef443.jpg
                 * type_id : http://y.baidu.com/cms/topic/webapp/2017/jilupian/index.html
                 * type : 4
                 * title : 独立纪录片中的中国摇滚乐
                 * tip_type : 0
                 * author :
                 */

                private String desc;
                private String pic;
                private String type_id;
                private int type;
                private String title;
                private int tip_type;
                private String author;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getType_id() {
                    return type_id;
                }

                public void setType_id(String type_id) {
                    this.type_id = type_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getTip_type() {
                    return tip_type;
                }

                public void setTip_type(int tip_type) {
                    this.tip_type = tip_type;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class FocusBean {
            /**
             * error_code : 22000
             * result : [{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/nmepre/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","code":"http://music.baidu.com/cms/webview/bigwig/lina/index.html","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148716121548117ff81ff504514f99a98824e064c9.jpg","randpic_desc":"厉娜生日粉丝征集"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871492610b7ca06dac293584058326bb7cb33e9e.jpg","randpic_desc":"第59届格莱美最佳爵士演唱专辑"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","code":"365048362","mo_type":5,"type":7,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138958d4bcc7b20838c8b954665c0f8f8354f8.jpg","randpic_desc":"第6周新歌榜 新年新歌抢先听 春晚成榜单赢家"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","code":"533370111","mo_type":2,"type":2,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148713282565e44202b9c610d3fcb68bd64723d0e9.jpg","randpic_desc":"爱又爱"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487105444c16bebe159e2c5ddc3810b0fa358a836.jpg","randpic_desc":"《明星私房歌》之秦俊杰陪你听歌聊故事"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","code":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","mo_type":4,"type":6,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487061134a9df656c2e4671fb7dda1ec89f6b6391.jpg","randpic_desc":"百度音乐独家策划"},{"randpic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","code":"1198","mo_type":9,"type":12,"is_publish":"111111","randpic_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14869785755f70c4847075339eb599a157c883e87f.jpg","randpic_desc":"第59届格莱美 天后之争阿黛尔成最大赢家"}]
             */

            private int error_code;
            private List<ResultBeanX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanX> result) {
                this.result = result;
            }

            public static class ResultBeanX {
                /**
                 * randpic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg
                 * code : http://music.baidu.com/cms/webview/topic_activity/nmepre/
                 * mo_type : 4
                 * type : 6
                 * is_publish : 111111
                 * randpic_iphone6 : http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871651726b2764cbbbe4284ee810079e5b395917.jpg
                 * randpic_desc : 百度音乐独家策划
                 */

                private String randpic;
                private String code;
                private int mo_type;
                private int type;
                private String is_publish;
                private String randpic_iphone6;
                private String randpic_desc;

                public String getRandpic() {
                    return randpic;
                }

                public void setRandpic(String randpic) {
                    this.randpic = randpic;
                }

                public String getCode() {
                    return code;
                }

                public void setCode(String code) {
                    this.code = code;
                }

                public int getMo_type() {
                    return mo_type;
                }

                public void setMo_type(int mo_type) {
                    this.mo_type = mo_type;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getIs_publish() {
                    return is_publish;
                }

                public void setIs_publish(String is_publish) {
                    this.is_publish = is_publish;
                }

                public String getRandpic_iphone6() {
                    return randpic_iphone6;
                }

                public void setRandpic_iphone6(String randpic_iphone6) {
                    this.randpic_iphone6 = randpic_iphone6;
                }

                public String getRandpic_desc() {
                    return randpic_desc;
                }

                public void setRandpic_desc(String randpic_desc) {
                    this.randpic_desc = randpic_desc;
                }
            }
        }

        public static class Mix22Bean {
            /**
             * error_code : 22000
             * result : [{"desc":"赵雷","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14853039815a65d461e42ec25c11779195e835ddad.jpg","type_id":"275347355","type":2,"title":"无法长大","tip_type":0,"author":"赵雷"},{"desc":"宇多田光","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609265600c65560203d96022a269af453fb8e4.jpg","type_id":"271948337","type":2,"title":"Fantôme","tip_type":0,"author":"宇多田光"},{"desc":"ZAYN/Taylor Swift","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1483609313124980270e3e6abec5a57ed362443386.jpg","type_id":"285427064","type":2,"title":"I Don\u2019t Wanna Live Forever (Fifty Shades Darker)","tip_type":0,"author":"ZAYN/Taylor Swift"}]
             */

            private int error_code;
            private List<ResultBeanXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXX> result) {
                this.result = result;
            }

            public static class ResultBeanXX {
                /**
                 * desc : 赵雷
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_14853039815a65d461e42ec25c11779195e835ddad.jpg
                 * type_id : 275347355
                 * type : 2
                 * title : 无法长大
                 * tip_type : 0
                 * author : 赵雷
                 */

                private String desc;
                private String pic;
                private String type_id;
                private int type;
                private String title;
                private int tip_type;
                private String author;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getType_id() {
                    return type_id;
                }

                public void setType_id(String type_id) {
                    this.type_id = type_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getTip_type() {
                    return tip_type;
                }

                public void setTip_type(int tip_type) {
                    this.tip_type = tip_type;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class ShowListBean {
            /**
             * error_code : 22000
             * result : [{"type":"learn","picture_iphone6":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_142ae6a390ad9fcdf8eeff6a72eac81c.jpg","picture":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_87bcbaf07c958c061d8bad05e1d79b37.jpg","web_url":"http://music.baidu.com/cms/webview/ktv_activity/20161123/"}]
             */

            private int error_code;
            private List<ResultBeanXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXX {
                /**
                 * type : learn
                 * picture_iphone6 : http://business.cdn.qianqian.com/qianqian/pic/bos_client_142ae6a390ad9fcdf8eeff6a72eac81c.jpg
                 * picture : http://business.cdn.qianqian.com/qianqian/pic/bos_client_87bcbaf07c958c061d8bad05e1d79b37.jpg
                 * web_url : http://music.baidu.com/cms/webview/ktv_activity/20161123/
                 */

                private String type;
                private String picture_iphone6;
                private String picture;
                private String web_url;

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getPicture_iphone6() {
                    return picture_iphone6;
                }

                public void setPicture_iphone6(String picture_iphone6) {
                    this.picture_iphone6 = picture_iphone6;
                }

                public String getPicture() {
                    return picture;
                }

                public void setPicture(String picture) {
                    this.picture = picture;
                }

                public String getWeb_url() {
                    return web_url;
                }

                public void setWeb_url(String web_url) {
                    this.web_url = web_url;
                }
            }
        }

        public static class EntryBean {
            /**
             * error_code : 22000
             * result : [{"day":"","title":"歌手","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14639875926652ed7c4988517cab87526f15d8f359.jpg","jump":"2"},{"day":"","title":"歌曲分类","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_146398764316d87d01865b91f90a598777b1569fdf.jpg","jump":"1"},{"day":"","title":"电台","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473839849b2fb772ae0ec435c68ffff814134e49d.jpg","jump":"8"},{"day":"","title":"会员专区","icon":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1473479784373fcb8805326ee3da6fc7fc3891a81a.jpg","jump":"9"}]
             */

            private int error_code;
            private List<ResultBeanXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXX {
                /**
                 * day :
                 * title : 歌手
                 * icon : http://business.cdn.qianqian.com/qianqian/pic/bos_client_14639875926652ed7c4988517cab87526f15d8f359.jpg
                 * jump : 2
                 */

                private String day;
                private String title;
                private String icon;
                private String jump;

                public String getDay() {
                    return day;
                }

                public void setDay(String day) {
                    this.day = day;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getIcon() {
                    return icon;
                }

                public void setIcon(String icon) {
                    this.icon = icon;
                }

                public String getJump() {
                    return jump;
                }

                public void setJump(String jump) {
                    this.jump = jump;
                }
            }
        }

        public static class SceneBean {
            /**
             * result : {"action":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b3fb43166d224f4a0e1143e30ff790529922d1b1.jpg","scene_name":"一个人","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f636afc379310a55e4d177f7b04543a98226103f.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"10"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/1f178a82b9014a9007da7e4daf773912b21bee5e.jpg","scene_name":"赖床","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/dc54564e9258d109b39702b1d658ccbf6c814db8.jpg","scene_model":"1","scene_desc":"每周总有那么7天不想起床","bgpic_ios":"","scene_id":"21"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/94cad1c8a786c917cd5a64c9cf3d70cf3ac757e0.jpg","scene_name":"在路上","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/b999a9014c086e06604a914805087bf40bd1cbd7.jpg","scene_model":"2","scene_desc":"","bgpic_ios":"","scene_id":"0"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b90e7bec54e736d15a00bff89d504fc2d562692a.jpg","scene_name":"工作","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/77c6a7efce1b9d1617f33262f4deb48f8c5464f9.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"12"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a5c27d1ed21b0ef4d176a9aedbc451da80cb3ea7.jpg","scene_name":"放松","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0b7b02087bf40ad1e3996ee0502c11dfa9ecceb0.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"8"}],"emotion":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/3bf33a87e950352a854306f85543fbf2b2118b1b.jpg","scene_name":"激动","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/5882b2b7d0a20cf4f1ac61dc71094b36acaf99f1.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"34"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/9d82d158ccbf6c810ea60f18ba3eb13532fa40a8.jpg","scene_name":"治愈","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/472309f790529822ffa5a6c0d0ca7bcb0a46d41b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"37"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/a1ec08fa513d26974c932aad53fbb2fb4216d8f9.jpg","scene_name":"开心","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/f703738da9773912e4621a62ff198618367ae269.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"38"}],"operation":[{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/faedab64034f78f04fd1977e7f310a55b2191c60.jpg","scene_name":"古风","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/2cf5e0fe9925bc313c5e079a59df8db1cb1370b4.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"157"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/bd3eb13533fa828bd727916efb1f4134970a5a32.jpg","scene_name":"新歌抢鲜听","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9213b07eca8065382359a31190dda144ad348204.jpg","scene_model":"1","scene_desc":"网罗全球最新歌曲","bgpic_ios":"","scene_id":"33"},{"icon_ios":"http://b.hiphotos.baidu.com/ting/pic/item/18d8bc3eb13533faf2ba9fa3aed3fd1f41345b2a.jpg","scene_name":"网络歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/9922720e0cf3d7ca73313874f51fbe096a63a9e8.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"156"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/4a36acaf2edda3cc469cb5ad07e93901203f92c6.jpg","scene_name":"校园歌曲","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/a71ea8d3fd1f4134ed57037c221f95cad1c85e4b.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"160"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c8ea15ce36d3d539961d09c13d87e950352ab08b.jpg","scene_name":"舒缓","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/0824ab18972bd40792add5ff7c899e510fb3094d.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"159"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/dbb44aed2e738bd461c6bebca78b87d6267ff95c.jpg","scene_name":"情人节","bgpic_android":"","icon_android":"http://c.hiphotos.baidu.com/ting/pic/item/63d0f703918fa0ecfe25630f219759ee3c6ddbd6.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"155"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/c2fdfc039245d6884448bf29a2c27d1ed31b24f0.jpg","scene_name":"经典老歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d058ccbf6c81800a68b98f0cb63533fa828b4757.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"161"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d01373f082025aaff566d3a4fcedab64034f1a0c.jpg","scene_name":"热歌","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/838ba61ea8d3fd1f55b20f55374e251f95ca5f21.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"162"},{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/cb8065380cd79123bb1999f9ab345982b3b78045.jpg","scene_name":"小清新","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/80cb39dbb6fd526672003a16ac18972bd407368c.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"158"}],"other":[{"icon_ios":"http://d.hiphotos.baidu.com/ting/pic/item/377adab44aed2e7364d7a8dc8101a18b87d6fa00.jpg","scene_name":"2000年代","bgpic_android":"","icon_android":"http://b.hiphotos.baidu.com/ting/pic/item/aa64034f78f0f736ec9dd4020d55b319ebc41355.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"71"},{"icon_ios":"http://a.hiphotos.baidu.com/ting/pic/item/d009b3de9c82d1582e8bac41860a19d8bc3e4231.jpg","scene_name":"说唱","bgpic_android":"","icon_android":"http://d.hiphotos.baidu.com/ting/pic/item/7c1ed21b0ef41bd5b37f6df756da81cb39db3d80.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"63"},{"icon_ios":"http://c.hiphotos.baidu.com/ting/pic/item/b2de9c82d158ccbfe74098ca1fd8bc3eb0354145.jpg","scene_name":"国语","bgpic_android":"","icon_android":"http://a.hiphotos.baidu.com/ting/pic/item/d439b6003af33a87423e9e19c15c10385343b566.jpg","scene_model":"1","scene_desc":"","bgpic_ios":"","scene_id":"42"}]}
             * error_code : 22000
             * config : [{"color_other":"","play_color":"","scene_version":0,"desc":"","end_time":0,"start_time":0,"scene_color":"","bgpic":"","bgpic_special":"","button_color":""}]
             */

            private ResultBeanXXXXX result;
            private int error_code;
            private List<ConfigBean> config;

            public ResultBeanXXXXX getResult() {
                return result;
            }

            public void setResult(ResultBeanXXXXX result) {
                this.result = result;
            }

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ConfigBean> getConfig() {
                return config;
            }

            public void setConfig(List<ConfigBean> config) {
                this.config = config;
            }

            public static class ResultBeanXXXXX {
                private List<ActionBean> action;
                private List<EmotionBean> emotion;
                private List<OperationBean> operation;
                private List<OtherBean> other;

                public List<ActionBean> getAction() {
                    return action;
                }

                public void setAction(List<ActionBean> action) {
                    this.action = action;
                }

                public List<EmotionBean> getEmotion() {
                    return emotion;
                }

                public void setEmotion(List<EmotionBean> emotion) {
                    this.emotion = emotion;
                }

                public List<OperationBean> getOperation() {
                    return operation;
                }

                public void setOperation(List<OperationBean> operation) {
                    this.operation = operation;
                }

                public List<OtherBean> getOther() {
                    return other;
                }

                public void setOther(List<OtherBean> other) {
                    this.other = other;
                }

                public static class ActionBean {
                    /**
                     * icon_ios : http://c.hiphotos.baidu.com/ting/pic/item/b3fb43166d224f4a0e1143e30ff790529922d1b1.jpg
                     * scene_name : 一个人
                     * bgpic_android :
                     * icon_android : http://c.hiphotos.baidu.com/ting/pic/item/f636afc379310a55e4d177f7b04543a98226103f.jpg
                     * scene_model : 1
                     * scene_desc :
                     * bgpic_ios :
                     * scene_id : 10
                     */

                    private String icon_ios;
                    private String scene_name;
                    private String bgpic_android;
                    private String icon_android;
                    private String scene_model;
                    private String scene_desc;
                    private String bgpic_ios;
                    private String scene_id;

                    public String getIcon_ios() {
                        return icon_ios;
                    }

                    public void setIcon_ios(String icon_ios) {
                        this.icon_ios = icon_ios;
                    }

                    public String getScene_name() {
                        return scene_name;
                    }

                    public void setScene_name(String scene_name) {
                        this.scene_name = scene_name;
                    }

                    public String getBgpic_android() {
                        return bgpic_android;
                    }

                    public void setBgpic_android(String bgpic_android) {
                        this.bgpic_android = bgpic_android;
                    }

                    public String getIcon_android() {
                        return icon_android;
                    }

                    public void setIcon_android(String icon_android) {
                        this.icon_android = icon_android;
                    }

                    public String getScene_model() {
                        return scene_model;
                    }

                    public void setScene_model(String scene_model) {
                        this.scene_model = scene_model;
                    }

                    public String getScene_desc() {
                        return scene_desc;
                    }

                    public void setScene_desc(String scene_desc) {
                        this.scene_desc = scene_desc;
                    }

                    public String getBgpic_ios() {
                        return bgpic_ios;
                    }

                    public void setBgpic_ios(String bgpic_ios) {
                        this.bgpic_ios = bgpic_ios;
                    }

                    public String getScene_id() {
                        return scene_id;
                    }

                    public void setScene_id(String scene_id) {
                        this.scene_id = scene_id;
                    }
                }

                public static class EmotionBean {
                    /**
                     * icon_ios : http://d.hiphotos.baidu.com/ting/pic/item/3bf33a87e950352a854306f85543fbf2b2118b1b.jpg
                     * scene_name : 激动
                     * bgpic_android :
                     * icon_android : http://b.hiphotos.baidu.com/ting/pic/item/5882b2b7d0a20cf4f1ac61dc71094b36acaf99f1.jpg
                     * scene_model : 1
                     * scene_desc :
                     * bgpic_ios :
                     * scene_id : 34
                     */

                    private String icon_ios;
                    private String scene_name;
                    private String bgpic_android;
                    private String icon_android;
                    private String scene_model;
                    private String scene_desc;
                    private String bgpic_ios;
                    private String scene_id;

                    public String getIcon_ios() {
                        return icon_ios;
                    }

                    public void setIcon_ios(String icon_ios) {
                        this.icon_ios = icon_ios;
                    }

                    public String getScene_name() {
                        return scene_name;
                    }

                    public void setScene_name(String scene_name) {
                        this.scene_name = scene_name;
                    }

                    public String getBgpic_android() {
                        return bgpic_android;
                    }

                    public void setBgpic_android(String bgpic_android) {
                        this.bgpic_android = bgpic_android;
                    }

                    public String getIcon_android() {
                        return icon_android;
                    }

                    public void setIcon_android(String icon_android) {
                        this.icon_android = icon_android;
                    }

                    public String getScene_model() {
                        return scene_model;
                    }

                    public void setScene_model(String scene_model) {
                        this.scene_model = scene_model;
                    }

                    public String getScene_desc() {
                        return scene_desc;
                    }

                    public void setScene_desc(String scene_desc) {
                        this.scene_desc = scene_desc;
                    }

                    public String getBgpic_ios() {
                        return bgpic_ios;
                    }

                    public void setBgpic_ios(String bgpic_ios) {
                        this.bgpic_ios = bgpic_ios;
                    }

                    public String getScene_id() {
                        return scene_id;
                    }

                    public void setScene_id(String scene_id) {
                        this.scene_id = scene_id;
                    }
                }

                public static class OperationBean {
                    /**
                     * icon_ios : http://c.hiphotos.baidu.com/ting/pic/item/faedab64034f78f04fd1977e7f310a55b2191c60.jpg
                     * scene_name : 古风
                     * bgpic_android :
                     * icon_android : http://c.hiphotos.baidu.com/ting/pic/item/2cf5e0fe9925bc313c5e079a59df8db1cb1370b4.jpg
                     * scene_model : 1
                     * scene_desc :
                     * bgpic_ios :
                     * scene_id : 157
                     */

                    private String icon_ios;
                    private String scene_name;
                    private String bgpic_android;
                    private String icon_android;
                    private String scene_model;
                    private String scene_desc;
                    private String bgpic_ios;
                    private String scene_id;

                    public String getIcon_ios() {
                        return icon_ios;
                    }

                    public void setIcon_ios(String icon_ios) {
                        this.icon_ios = icon_ios;
                    }

                    public String getScene_name() {
                        return scene_name;
                    }

                    public void setScene_name(String scene_name) {
                        this.scene_name = scene_name;
                    }

                    public String getBgpic_android() {
                        return bgpic_android;
                    }

                    public void setBgpic_android(String bgpic_android) {
                        this.bgpic_android = bgpic_android;
                    }

                    public String getIcon_android() {
                        return icon_android;
                    }

                    public void setIcon_android(String icon_android) {
                        this.icon_android = icon_android;
                    }

                    public String getScene_model() {
                        return scene_model;
                    }

                    public void setScene_model(String scene_model) {
                        this.scene_model = scene_model;
                    }

                    public String getScene_desc() {
                        return scene_desc;
                    }

                    public void setScene_desc(String scene_desc) {
                        this.scene_desc = scene_desc;
                    }

                    public String getBgpic_ios() {
                        return bgpic_ios;
                    }

                    public void setBgpic_ios(String bgpic_ios) {
                        this.bgpic_ios = bgpic_ios;
                    }

                    public String getScene_id() {
                        return scene_id;
                    }

                    public void setScene_id(String scene_id) {
                        this.scene_id = scene_id;
                    }
                }

                public static class OtherBean {
                    /**
                     * icon_ios : http://d.hiphotos.baidu.com/ting/pic/item/377adab44aed2e7364d7a8dc8101a18b87d6fa00.jpg
                     * scene_name : 2000年代
                     * bgpic_android :
                     * icon_android : http://b.hiphotos.baidu.com/ting/pic/item/aa64034f78f0f736ec9dd4020d55b319ebc41355.jpg
                     * scene_model : 1
                     * scene_desc :
                     * bgpic_ios :
                     * scene_id : 71
                     */

                    private String icon_ios;
                    private String scene_name;
                    private String bgpic_android;
                    private String icon_android;
                    private String scene_model;
                    private String scene_desc;
                    private String bgpic_ios;
                    private String scene_id;

                    public String getIcon_ios() {
                        return icon_ios;
                    }

                    public void setIcon_ios(String icon_ios) {
                        this.icon_ios = icon_ios;
                    }

                    public String getScene_name() {
                        return scene_name;
                    }

                    public void setScene_name(String scene_name) {
                        this.scene_name = scene_name;
                    }

                    public String getBgpic_android() {
                        return bgpic_android;
                    }

                    public void setBgpic_android(String bgpic_android) {
                        this.bgpic_android = bgpic_android;
                    }

                    public String getIcon_android() {
                        return icon_android;
                    }

                    public void setIcon_android(String icon_android) {
                        this.icon_android = icon_android;
                    }

                    public String getScene_model() {
                        return scene_model;
                    }

                    public void setScene_model(String scene_model) {
                        this.scene_model = scene_model;
                    }

                    public String getScene_desc() {
                        return scene_desc;
                    }

                    public void setScene_desc(String scene_desc) {
                        this.scene_desc = scene_desc;
                    }

                    public String getBgpic_ios() {
                        return bgpic_ios;
                    }

                    public void setBgpic_ios(String bgpic_ios) {
                        this.bgpic_ios = bgpic_ios;
                    }

                    public String getScene_id() {
                        return scene_id;
                    }

                    public void setScene_id(String scene_id) {
                        this.scene_id = scene_id;
                    }
                }
            }

            public static class ConfigBean {
                /**
                 * color_other :
                 * play_color :
                 * scene_version : 0
                 * desc :
                 * end_time : 0
                 * start_time : 0
                 * scene_color :
                 * bgpic :
                 * bgpic_special :
                 * button_color :
                 */

                private String color_other;
                private String play_color;
                private int scene_version;
                private String desc;
                private int end_time;
                private int start_time;
                private String scene_color;
                private String bgpic;
                private String bgpic_special;
                private String button_color;

                public String getColor_other() {
                    return color_other;
                }

                public void setColor_other(String color_other) {
                    this.color_other = color_other;
                }

                public String getPlay_color() {
                    return play_color;
                }

                public void setPlay_color(String play_color) {
                    this.play_color = play_color;
                }

                public int getScene_version() {
                    return scene_version;
                }

                public void setScene_version(int scene_version) {
                    this.scene_version = scene_version;
                }

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public int getEnd_time() {
                    return end_time;
                }

                public void setEnd_time(int end_time) {
                    this.end_time = end_time;
                }

                public int getStart_time() {
                    return start_time;
                }

                public void setStart_time(int start_time) {
                    this.start_time = start_time;
                }

                public String getScene_color() {
                    return scene_color;
                }

                public void setScene_color(String scene_color) {
                    this.scene_color = scene_color;
                }

                public String getBgpic() {
                    return bgpic;
                }

                public void setBgpic(String bgpic) {
                    this.bgpic = bgpic;
                }

                public String getBgpic_special() {
                    return bgpic_special;
                }

                public void setBgpic_special(String bgpic_special) {
                    this.bgpic_special = bgpic_special;
                }

                public String getButton_color() {
                    return button_color;
                }

                public void setButton_color(String button_color) {
                    this.button_color = button_color;
                }
            }
        }

        public static class Mix5Bean {
            /**
             * error_code : 22000
             * result : [{"desc":"陈奕迅/谭咏麟","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487151573609e89ef52919f79cbe35765eee3a62b.jpg","type_id":"315780937","type":5,"title":"明天何其多 歌词版","tip_type":0,"author":"陈奕迅/谭咏麟"},{"desc":"Mariah Carey","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154200fa8d3467ed1c58fce9da787d717883db.jpg","type_id":"315553324","type":5,"title":"I Don't","tip_type":0,"author":"Mariah Carey"},{"desc":"郑秀晶/June One Kim","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871541477c682e00ce7d19c76bc7ff887c3f028c.jpg","type_id":"315797607","type":5,"title":"I Don`t Wanna Love You","tip_type":0,"author":"郑秀晶/June One Kim"},{"desc":"杨乃文","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487154248f18c469ed21ad174b382bcdce6103303.jpg","type_id":"315779156","type":5,"title":"如一","tip_type":0,"author":"杨乃文"},{"desc":"卢庚戌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487134051e240959330a4fe6d4018429ab3b2fda5.jpg","type_id":"315798325","type":5,"title":"大鱼","tip_type":0,"author":"卢庚戌"},{"desc":"Emma Stone/Ryan Gosling","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487133178082c0f52c7f63af6c41273d892404bc5.jpg","type_id":"311043659","type":5,"title":"《爱乐之城》主题曲MV《繁星之城》","tip_type":0,"author":"Emma Stone/Ryan Gosling"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXX {
                /**
                 * desc : 陈奕迅/谭咏麟
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487151573609e89ef52919f79cbe35765eee3a62b.jpg
                 * type_id : 315780937
                 * type : 5
                 * title : 明天何其多 歌词版
                 * tip_type : 0
                 * author : 陈奕迅/谭咏麟
                 */

                private String desc;
                private String pic;
                private String type_id;
                private int type;
                private String title;
                private int tip_type;
                private String author;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getType_id() {
                    return type_id;
                }

                public void setType_id(String type_id) {
                    this.type_id = type_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getTip_type() {
                    return tip_type;
                }

                public void setTip_type(int tip_type) {
                    this.tip_type = tip_type;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class Mix1Bean {
            /**
             * error_code : 22000
             * result : [{"desc":"田馥甄/井柏然","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871779237e3fa7c4a0ab41c2bea4f54398a26bb9.jpg","type_id":"315749329","type":2,"title":"美女与野兽","tip_type":0,"author":"田馥甄/井柏然"},{"desc":"T榜","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487177568fa610135e0e46d056785d365d007bd80.jpg","type_id":"533391615","type":2,"title":"T榜力量9","tip_type":0,"author":"T榜"},{"desc":"Maroon 5/Future","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487138087149c535567086c4410a100f6f3177745.jpg","type_id":"315796013","type":2,"title":"Cold","tip_type":0,"author":"Maroon 5/Future"},{"desc":"by2","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871330475cedc760f8d281b8f82e5742cde17f68.jpg","type_id":"533370111","type":2,"title":"爱又爱","tip_type":0,"author":"by2"},{"desc":"何静/高阿鑫","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871239441647ee7bff0e261faf9d797790b7b423.jpg","type_id":"533369902","type":2,"title":"我想调慢钟表","tip_type":0,"author":"何静/高阿鑫"},{"desc":"张信哲","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487037784283e0e6469604b01c1e75132ab9a0835.jpg","type_id":"533357576","type":2,"title":"夏夜星空海","tip_type":0,"author":"张信哲"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXX {
                /**
                 * desc : 田馥甄/井柏然
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_14871779237e3fa7c4a0ab41c2bea4f54398a26bb9.jpg
                 * type_id : 315749329
                 * type : 2
                 * title : 美女与野兽
                 * tip_type : 0
                 * author : 田馥甄/井柏然
                 */

                private String desc;
                private String pic;
                private String type_id;
                private int type;
                private String title;
                private int tip_type;
                private String author;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getType_id() {
                    return type_id;
                }

                public void setType_id(String type_id) {
                    this.type_id = type_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getTip_type() {
                    return tip_type;
                }

                public void setTip_type(int tip_type) {
                    this.tip_type = tip_type;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class RecsongBean {
            /**
             * error_code : 22000
             * result : [{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"我多么羡慕你","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"2087714","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/88405622/88405622.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"手语","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"31891016","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"伴奏/纯音乐,现场","title":"婚前的女人","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"942280","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127498985/127498985.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"你要的未来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"12313517","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/127512008/127512008.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"你是否天使","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"284712","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/6766a57edcba8381320640d63148539e/262029352/262029352.jpg","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"孩子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"211934","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/80479BCF66F5FB9C6D1EFD6B8E777FBD/252897647/252897647.jpg@s_0,w_500","author":"黄贯中"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"飞行鱼","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"586322","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/124502286/124502286.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"放飞机","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"23165164","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89209602/89209602.jpg@s_0,w_500","author":"李克勤"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"哪里都是你","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"32934359","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89325459/89325459.jpg@s_0,w_500","author":"周杰伦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"走在凌晨的影子","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"482446","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A3169CC5C47C5BEF6F1F0468AEE6C83A/252272079/252272079.jpg@s_0,w_500","author":"赵传"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"心结","bitrate_fee":"{\"0\":\"129|-1\",\"1\":\"-1|-1\"}","song_id":"954672","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/89788745/89788745.jpg@s_0,w_500","author":"周传雄"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"You Made Me Believe In Magic","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7314210","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/854559BF85BB25FE46CD6CA910AF4389/252488661/252488661.jpg@s_0,w_500","author":"张国荣"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"杂念","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1064626","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/E953C002DF377E6912474C60CA03CCCF/252484140/252484140.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"迷思左岸","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7328899","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/36FB3F07472320CBCE40E5903189A713/252474615/252474615.jpg@s_0,w_500","author":"熊天平"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"今夜你会不会来","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7317554","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/pic/89844326/89844326.jpg@s_0,w_500","author":"黎明"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"三生三世","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"458313","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/A627C3592BBD179AFB36D76EB63465B3/252493369/252493369.jpg@s_0,w_500","author":"童安格"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"Alone (Infinite H)","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"120001229","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/120001138/120001138.jpg@s_0,w_500","author":"INFINITE"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"变幻是缘份","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"7332393","has_mv_mobile":"1","pic_premium":"http://musicdata.baidu.com/data2/music/315112CED2A7213F8F0A5A7FD4D33E5E/252785827/252785827.jpg@s_0,w_500","author":"钟镇涛"},{"resource_type_ext":"0","learn":"1","del_status":"0","korean_bb_song":"0","versions":"","title":"怀念的播音员","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"550768","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/music/54BD4633EF1E2392C8F2D0736F20A60B/252262549/252262549.jpg@s_0,w_500","author":"齐秦"},{"resource_type_ext":"0","learn":"0","del_status":"0","korean_bb_song":"0","versions":"","title":"嘭门","bitrate_fee":"{\"0\":\"0|0\",\"1\":\"0|0\"}","song_id":"1564131","has_mv_mobile":"0","pic_premium":"http://musicdata.baidu.com/data2/pic/bdebebacabef0d367fe9e6cfb59f9b17/261985908/261985908.jpg","author":"李克勤"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXX {
                /**
                 * resource_type_ext : 0
                 * learn : 0
                 * del_status : 0
                 * korean_bb_song : 0
                 * versions :
                 * title : 我多么羡慕你
                 * bitrate_fee : {"0":"0|0","1":"0|0"}
                 * song_id : 2087714
                 * has_mv_mobile : 0
                 * pic_premium : http://musicdata.baidu.com/data2/pic/88405622/88405622.jpg@s_0,w_500
                 * author : 齐秦
                 */

                private String resource_type_ext;
                private String learn;
                private String del_status;
                private String korean_bb_song;
                private String versions;
                private String title;
                private String bitrate_fee;
                private String song_id;
                private String has_mv_mobile;
                private String pic_premium;
                private String author;

                public String getResource_type_ext() {
                    return resource_type_ext;
                }

                public void setResource_type_ext(String resource_type_ext) {
                    this.resource_type_ext = resource_type_ext;
                }

                public String getLearn() {
                    return learn;
                }

                public void setLearn(String learn) {
                    this.learn = learn;
                }

                public String getDel_status() {
                    return del_status;
                }

                public void setDel_status(String del_status) {
                    this.del_status = del_status;
                }

                public String getKorean_bb_song() {
                    return korean_bb_song;
                }

                public void setKorean_bb_song(String korean_bb_song) {
                    this.korean_bb_song = korean_bb_song;
                }

                public String getVersions() {
                    return versions;
                }

                public void setVersions(String versions) {
                    this.versions = versions;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getBitrate_fee() {
                    return bitrate_fee;
                }

                public void setBitrate_fee(String bitrate_fee) {
                    this.bitrate_fee = bitrate_fee;
                }

                public String getSong_id() {
                    return song_id;
                }

                public void setSong_id(String song_id) {
                    this.song_id = song_id;
                }

                public String getHas_mv_mobile() {
                    return has_mv_mobile;
                }

                public void setHas_mv_mobile(String has_mv_mobile) {
                    this.has_mv_mobile = has_mv_mobile;
                }

                public String getPic_premium() {
                    return pic_premium;
                }

                public void setPic_premium(String pic_premium) {
                    this.pic_premium = pic_premium;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class RadioBean {
            /**
             * error_code : 22000
             * result : [{"desc":"都市情感","itemid":"13420598","title":"在那座阴雨的小城里，我从未忘记你-【晨曦微露】","album_id":"12380577","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_9b33d3ec6ac16f4c7997ff0486be1baf.jpg"},{"desc":"都市情感","itemid":"13420721","title":"《好可惜》：感谢你曾出现在我的生活里（主播：秋婉）","album_id":"12545344","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_71cc1564df5da0d614eefd7003fe8fc3.jpg"},{"desc":"都市情感","itemid":"13416365","title":"Vol.209找到自己真正热爱的东西（黎小妖）【时光听得见】","album_id":"13028457","type":"lebo","channelid":"11373553","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_e57f0ec830b6fe312c739691f6544df1.jpg"},{"desc":"音乐推荐","itemid":"13416522","title":"中国摇滚十大新歌榜丨一月","album_id":"1437655","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1999c69ffd5c60cca64f24a408998786.jpg"},{"desc":"音乐推荐","itemid":"13416370","title":"第239期：只要你愿意，我会陪你很久 - 明明","album_id":"9697691","type":"lebo","channelid":"11373552","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_a6d2a51e5eb0f4891aa76dcca8fe0b33.jpg"},{"desc":"段子笑话","itemid":"13416211","title":"为什么年轻人越来越不喜欢过年","album_id":"1175169","type":"lebo","channelid":"11373547","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_d61a5ce5fc7d9fca0381f90bc319463d.jpg"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXXX {
                /**
                 * desc : 都市情感
                 * itemid : 13420598
                 * title : 在那座阴雨的小城里，我从未忘记你-【晨曦微露】
                 * album_id : 12380577
                 * type : lebo
                 * channelid : 11373553
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_9b33d3ec6ac16f4c7997ff0486be1baf.jpg
                 */

                private String desc;
                private String itemid;
                private String title;
                private String album_id;
                private String type;
                private String channelid;
                private String pic;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getItemid() {
                    return itemid;
                }

                public void setItemid(String itemid) {
                    this.itemid = itemid;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getAlbum_id() {
                    return album_id;
                }

                public void setAlbum_id(String album_id) {
                    this.album_id = album_id;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public String getChannelid() {
                    return channelid;
                }

                public void setChannelid(String channelid) {
                    this.channelid = channelid;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }
            }
        }

        public static class NewSongBean {
            /**
             * error_code : 22000
             * result : {"pic_500":"http://b.hiphotos.baidu.com/ting/pic/item/a50f4bfbfbedab64bcae572ef136afc378311e7b.jpg","listid":"5126","song_info":[{"song_id":"261812117","title":"二十四小时","pic_premium":"http://qukufile2.qianqian.com/data2/pic/261811991/261811991.jpg@s_0,w_500","author":"陈坤,韩庚,大鹏,吴磊,尹正"},{"song_id":"74109283","title":"灵主不悔《画江湖之灵主》手游暨动漫主题曲","author":"汪苏泷"},{"song_id":"261496612","title":"Protocole","pic_premium":"http://qukufile2.qianqian.com/data2/pic/07a830e962bbb4e58e29842f45d44b66/261496583/261496583.jpg@s_0,w_500","author":"Alpha Wann"}]}
             */

            private int error_code;
            private ResultBeanXXXXXXXXXX result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public ResultBeanXXXXXXXXXX getResult() {
                return result;
            }

            public void setResult(ResultBeanXXXXXXXXXX result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXXXX {
                /**
                 * pic_500 : http://b.hiphotos.baidu.com/ting/pic/item/a50f4bfbfbedab64bcae572ef136afc378311e7b.jpg
                 * listid : 5126
                 * song_info : [{"song_id":"261812117","title":"二十四小时","pic_premium":"http://qukufile2.qianqian.com/data2/pic/261811991/261811991.jpg@s_0,w_500","author":"陈坤,韩庚,大鹏,吴磊,尹正"},{"song_id":"74109283","title":"灵主不悔《画江湖之灵主》手游暨动漫主题曲","author":"汪苏泷"},{"song_id":"261496612","title":"Protocole","pic_premium":"http://qukufile2.qianqian.com/data2/pic/07a830e962bbb4e58e29842f45d44b66/261496583/261496583.jpg@s_0,w_500","author":"Alpha Wann"}]
                 */

                private String pic_500;
                private String listid;
                private List<SongInfoBean> song_info;

                public String getPic_500() {
                    return pic_500;
                }

                public void setPic_500(String pic_500) {
                    this.pic_500 = pic_500;
                }

                public String getListid() {
                    return listid;
                }

                public void setListid(String listid) {
                    this.listid = listid;
                }

                public List<SongInfoBean> getSong_info() {
                    return song_info;
                }

                public void setSong_info(List<SongInfoBean> song_info) {
                    this.song_info = song_info;
                }

                public static class SongInfoBean {
                    /**
                     * song_id : 261812117
                     * title : 二十四小时
                     * pic_premium : http://qukufile2.qianqian.com/data2/pic/261811991/261811991.jpg@s_0,w_500
                     * author : 陈坤,韩庚,大鹏,吴磊,尹正
                     */

                    private String song_id;
                    private String title;
                    private String pic_premium;
                    private String author;

                    public String getSong_id() {
                        return song_id;
                    }

                    public void setSong_id(String song_id) {
                        this.song_id = song_id;
                    }

                    public String getTitle() {
                        return title;
                    }

                    public void setTitle(String title) {
                        this.title = title;
                    }

                    public String getPic_premium() {
                        return pic_premium;
                    }

                    public void setPic_premium(String pic_premium) {
                        this.pic_premium = pic_premium;
                    }

                    public String getAuthor() {
                        return author;
                    }

                    public void setAuthor(String author) {
                        this.author = author;
                    }
                }
            }
        }

        public static class DiyBean {
            /**
             * error_code : 22000
             * result : [{"position":1,"tag":"华语,流行,经典","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/83426ed526f062f75d5474b58dd49a7d.jpg","title":"【环球之音】一人一首华语经典","collectnum":16,"type":"gedan","listenum":10074,"listid":"365052526"},{"position":2,"tag":"华语,民谣","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ba7032ad93e6b764daea97ea571a834a.jpg","title":"民谣歌手以歌行至大江南北","collectnum":14,"type":"gedan","listenum":5288,"listid":"365047946"},{"position":3,"tag":"欧美,RnB/Soul,流行","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a3370926b81187627e3d8b4193c1537b.jpg","title":"前奏沦陷|R&B深情对唱","collectnum":2,"type":"gedan","listenum":1742,"listid":"365048225"},{"position":4,"tag":"欧美,爵士,放松","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b06eda3237fffb4e9958315e9d0cccd2.jpg","title":"【环球之音】Verve爵士经典时刻","collectnum":174,"type":"gedan","listenum":33655,"listid":"364201294"},{"position":5,"tag":"流行,韩语","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ebbcaf4493c16839d3f4adf30f56aa5b.jpg","title":"韩语|爱情有千百种模样","collectnum":4,"type":"gedan","listenum":1317,"listid":"365047559"},{"position":6,"tag":"华语,流行,婚礼","songidlist":[],"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4873ac5a497caae47af2d77e4b7dfa4a.jpg","title":"浪漫华语，赠予你美妙婚礼","collectnum":37,"type":"gedan","listenum":8651,"listid":"364515713"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXXXXX {
                /**
                 * position : 1
                 * tag : 华语,流行,经典
                 * songidlist : []
                 * pic : http://musicugc.cdn.qianqian.com/ugcdiy/pic/83426ed526f062f75d5474b58dd49a7d.jpg
                 * title : 【环球之音】一人一首华语经典
                 * collectnum : 16
                 * type : gedan
                 * listenum : 10074
                 * listid : 365052526
                 */

                private int position;
                private String tag;
                private String pic;
                private String title;
                private int collectnum;
                private String type;
                private int listenum;
                private String listid;
                private List<?> songidlist;

                public int getPosition() {
                    return position;
                }

                public void setPosition(int position) {
                    this.position = position;
                }

                public String getTag() {
                    return tag;
                }

                public void setTag(String tag) {
                    this.tag = tag;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getCollectnum() {
                    return collectnum;
                }

                public void setCollectnum(int collectnum) {
                    this.collectnum = collectnum;
                }

                public String getType() {
                    return type;
                }

                public void setType(String type) {
                    this.type = type;
                }

                public int getListenum() {
                    return listenum;
                }

                public void setListenum(int listenum) {
                    this.listenum = listenum;
                }

                public String getListid() {
                    return listid;
                }

                public void setListid(String listid) {
                    this.listid = listid;
                }

                public List<?> getSongidlist() {
                    return songidlist;
                }

                public void setSongidlist(List<?> songidlist) {
                    this.songidlist = songidlist;
                }
            }
        }

        public static class Mod7Bean {
            /**
             * error_code : 22000
             * result : [{"desc":"百度音乐独家DJ节目《有待咖啡》 | 第三期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487149365bb48e665bb7a91297610328af8db770d.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/youdai3/","type":4,"title":"本届格莱美\u201c最佳爵士乐演唱专辑奖\u201d注定颁给他？","tip_type":0,"author":""},{"desc":"明星私房歌 | 听偶像推荐的歌","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870629150d5ac6732b5390b8d56bd646e62d281e.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/mxsfgqjj/","type":4,"title":"秦俊杰陪你听歌聊故事","tip_type":0,"author":""},{"desc":"一周音乐热 | 网罗一周乐坛动态！","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14870613862ce10bb200beda7a0c2d17cac247c614.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/MUSICHOT66/","type":4,"title":"Lady Gaga化身老司机，这车你坐不坐？","tip_type":0,"author":""},{"desc":"郭顶的这张专辑得听一听","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148706176453088e4ce24db5377be08a504614ce51.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/guoding214/","type":4,"title":"一个人的情人节","tip_type":0,"author":""},{"desc":"音乐大人物 | 带给你绝妙的音乐，独特的故事","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1486969080b97701a0721f433be0500154b851ae02.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/yydrwdzw/index.html","type":4,"title":"专访大张伟 | 我是一个勤劳能干的人间精品","tip_type":0,"author":""},{"desc":"百度音乐独家DJ节目《在云端》 | 第六期","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_148671206164196ca7e2128d013214c1b95386514a.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/linhai6/","type":4,"title":"娱乐圈中，每首情歌的背后，都有一段故事","tip_type":0,"author":""},{"desc":"爱豆show | 带你跟进新、热idol的脚步","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1485156345f2157eaead005f646104a6521ff2f32f.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activity/idolshow15/index.html","type":4,"title":"这些对唱So Sweet~","tip_type":0,"author":""},{"desc":"跟着音乐 环球世界 | 第二期  Island","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_14848281717f5b2bd029ebb0ddf6561779e1af4226.jpg","type_id":"http://music.baidu.com/cms/webview/topic_activiity/hqisland/index.html","type":4,"title":"一个影响全世界的小岛......","tip_type":0,"author":""},{"desc":"音乐风格馆 | 为你解读各种音乐的魅力","pic":"http://business.cdn.qianqian.com/qianqian/pic/bos_client_1480931404b93a37d50116cfaf173e2e09259abbf3.jpg","type_id":"http://music.baidu.com/cms/webview/bigwig/yyfgg_v2/index.html","type":4,"title":"方大同实力解读：新灵魂乐的\u201c前世今生\u201d","tip_type":0,"author":""}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXXXXXX {
                /**
                 * desc : 百度音乐独家DJ节目《有待咖啡》 | 第三期
                 * pic : http://business.cdn.qianqian.com/qianqian/pic/bos_client_1487149365bb48e665bb7a91297610328af8db770d.jpg
                 * type_id : http://music.baidu.com/cms/webview/topic_activity/youdai3/
                 * type : 4
                 * title : 本届格莱美“最佳爵士乐演唱专辑奖”注定颁给他？
                 * tip_type : 0
                 * author :
                 */

                private String desc;
                private String pic;
                private String type_id;
                private int type;
                private String title;
                private int tip_type;
                private String author;

                public String getDesc() {
                    return desc;
                }

                public void setDesc(String desc) {
                    this.desc = desc;
                }

                public String getPic() {
                    return pic;
                }

                public void setPic(String pic) {
                    this.pic = pic;
                }

                public String getType_id() {
                    return type_id;
                }

                public void setType_id(String type_id) {
                    this.type_id = type_id;
                }

                public int getType() {
                    return type;
                }

                public void setType(int type) {
                    this.type = type;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public int getTip_type() {
                    return tip_type;
                }

                public void setTip_type(int tip_type) {
                    this.tip_type = tip_type;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }

        public static class KingBean {
            /**
             * error_code : 22000
             * result : [{"pic_big":"http://musicdata.baidu.com/data2/pic/750be293f2768372fece0bc0cc3cc40c/299549244/299549244.jpg@s_0,w_150","title":"钢铁森林","author":"冯建宇"},{"pic_big":"http://musicdata.baidu.com/data2/pic/dee57a075da12ee283c6e9ba9dbf9b66/531451362/531451362.jpg@s_0,w_150","title":" Goodbye","author":"2NE1"},{"pic_big":"http://musicdata.baidu.com/data2/pic/522740217/5e43477ce1f6bf34e72595936019f5e2/522740217.jpg@s_0,w_150","title":"极光","author":"郑兴琦"}]
             */

            private int error_code;
            private List<ResultBeanXXXXXXXXXXXXX> result;

            public int getError_code() {
                return error_code;
            }

            public void setError_code(int error_code) {
                this.error_code = error_code;
            }

            public List<ResultBeanXXXXXXXXXXXXX> getResult() {
                return result;
            }

            public void setResult(List<ResultBeanXXXXXXXXXXXXX> result) {
                this.result = result;
            }

            public static class ResultBeanXXXXXXXXXXXXX {
                /**
                 * pic_big : http://musicdata.baidu.com/data2/pic/750be293f2768372fece0bc0cc3cc40c/299549244/299549244.jpg@s_0,w_150
                 * title : 钢铁森林
                 * author : 冯建宇
                 */

                private String pic_big;
                private String title;
                private String author;

                public String getPic_big() {
                    return pic_big;
                }

                public void setPic_big(String pic_big) {
                    this.pic_big = pic_big;
                }

                public String getTitle() {
                    return title;
                }

                public void setTitle(String title) {
                    this.title = title;
                }

                public String getAuthor() {
                    return author;
                }

                public void setAuthor(String author) {
                    this.author = author;
                }
            }
        }
    }

    public static class ModuleBean {
        /**
         * link_url :
         * pos : 1
         * title : 焦点图
         * key : focus
         * picurl :
         * title_more :
         * style : 1
         * jump :
         */

        private String link_url;
        private int pos;
        private String title;
        private String key;
        private String picurl;
        private String title_more;
        private int style;
        private String jump;

        public String getLink_url() {
            return link_url;
        }

        public void setLink_url(String link_url) {
            this.link_url = link_url;
        }

        public int getPos() {
            return pos;
        }

        public void setPos(int pos) {
            this.pos = pos;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getKey() {
            return key;
        }

        public void setKey(String key) {
            this.key = key;
        }

        public String getPicurl() {
            return picurl;
        }

        public void setPicurl(String picurl) {
            this.picurl = picurl;
        }

        public String getTitle_more() {
            return title_more;
        }

        public void setTitle_more(String title_more) {
            this.title_more = title_more;
        }

        public int getStyle() {
            return style;
        }

        public void setStyle(int style) {
            this.style = style;
        }

        public String getJump() {
            return jump;
        }

        public void setJump(String jump) {
            this.jump = jump;
        }
    }
}
