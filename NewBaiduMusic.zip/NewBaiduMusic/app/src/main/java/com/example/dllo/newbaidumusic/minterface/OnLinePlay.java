package com.example.dllo.newbaidumusic.minterface;

import java.util.List;

/**
 * Created by dllo on 17/2/25.
 */

public interface OnLinePlay {
     void playonline(List<String> songId, int Index, boolean IsLocal,String url);
}
