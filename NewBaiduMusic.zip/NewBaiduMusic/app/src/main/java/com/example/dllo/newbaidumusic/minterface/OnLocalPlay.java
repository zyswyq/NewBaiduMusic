package com.example.dllo.newbaidumusic.minterface;

/**
 * Created by dllo on 17/2/23.
 */

public interface OnLocalPlay {

    void playitem(int position,int type,boolean isLocal);
}
