package com.example.dllo.newbaidumusic.bean;

import java.util.List;

/**
 * Created by dllo on 17/2/11.
 */

public class Dynamic {


    /**
     * new_msg_num : 0
     * msg : [{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@w_500,h_500,o_1"}],"rtime":1486782859,"share_num":0,"ctime":1486782805,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","userid":"2698311496","username":"乐坛大湿兄"},"comment_num":0,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":315705707,"tinguid":2716,"content_type":0,"artist_name":"Katy Perry,Skip Marley","status":0,"title":"Chained To The Rhythm","pic":"http://musicdata.baidu.com/data2/pic/21c926ccadebf7156689961ac234393c/315705698/315705698.jpg@s_0,w_90","artist_id":"1512"},"msg_users":[],"is_sync":0,"msg":"Katy Perry水果姐带着新单强势回归！[花心][花心]此次Katy Perry 联手Skip Marley 推出新单《Chained to the Rhythm》，新曲由洗牙姐Sia和冠单制造机Max Martin参与填词，浓浓的复古迪斯科风炒鸡赞，期待这次再次夺冠！来跟着the Rhythm一起摇摆吧！","zan_num":0,"msgid":"83064","status":0},{"topic":{"pic_750x215":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_750,h_215,o_1","pic_50x50":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@o_1|s_2,w_50,h_50","pic_350x170":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_350,h_170,o_1","editor":"houyue","attr":"a:8:{s:11:\"topic_title\";s:39:\"今年春节你妈逼你结婚了吗？\";s:4:\"desc\";s:297:\"历年来过年回家被三姑六婆问得最多的问题就是：\u201c孩子，有对象了吗？啥时候结婚啊？\u2026\u201d今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的\u201c攻略\u201d吧！\";s:8:\"userlist\";s:0:\"\";s:3:\"pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg\";s:7:\"min_pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg\";s:6:\"status\";i:0;s:6:\"editor\";s:6:\"houyue\";s:5:\"ctime\";s:10:\"1485923015\";}","topic_title":"今年春节你妈逼你结婚了吗？","ctime":1485923015,"is_recommend":1,"topic_id":"1098","pic_980x280":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_980,h_280,o_1","pic_min":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg","mod_state":0,"desc":"历年来过年回家被三姑六婆问得最多的问题就是：\u201c孩子，有对象了吗？啥时候结婚啊？\u2026\u201d今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的\u201c攻略\u201d吧！","pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg","pic_700x340":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_700,h_340,o_1","min_pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg","usertype":1,"pic_180x88":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_180,h_88,o_1","nums":149,"status":0},"msgid":"1098","msgtype":2},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/98e176faea656d9272090e9966af7c43.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a97fceb93d354670986cf458c9b630ab.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/568e8682ac55ddd21cc235336d70431d.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/482756ba7914b1e6ef487b1c01b28ded.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b43c5941fe5b6075d0963a689859e88b.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a9aeaaf1f65876c42592d8b5991826ad.jpg@w_500,h_500,o_1"}],"rtime":1486725533,"share_num":13,"ctime":1486725503,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/79cb03b824b6d3fa2c0e388158ba0a73.jpg","flag":"001","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/79cb03b824b6d3fa2c0e388158ba0a73.jpg","userid":"2698311358","username":"歌单实验室"},"comment_num":2,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":6915,"pic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2dea81f9865057d58953a643206bdae7.jpg","content_type":1,"status":0,"title":"中国民歌新编精选"},"msg_users":[],"is_sync":0,"msg":"所有的民歌都是时调，都是昔日的流行歌，新民歌来自翻新的土地，脱胎于新生活的语言，愉悦着新的时代。","zan_num":23,"msgid":"81870","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2cc314112ed9b0bd5138c8b6d9d64870.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0e24cd152e139f6844f619e2c7ff3743.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/ab23aaa297908fd729db097f5aece0f0.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f0424df019069b2782bd7534c0362831.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/86d03d7a2354176e2d163d7e20a6941a.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/015f3abd5ec572309303b833ddc072dc.jpg@w_500,h_500,o_1"}],"rtime":1486722258,"share_num":28,"ctime":1486722249,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f5889974d146ccd81bac01a694717937.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/f5889974d146ccd81bac01a694717937.jpg","userid":"2698316512","username":"我还是个宝宝"},"comment_num":12,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":238995074,"tinguid":81381913,"content_type":0,"artist_name":"TFBOYS","status":0,"title":"宠爱","pic":"http://musicdata.baidu.com/data2/pic/242095429/242095429.jpg@s_0,w_90","artist_id":"86767985"},"msg_users":[],"is_sync":0,"msg":"今天TFBOYS组合队长王俊凯现身北京电影学院参加艺考，结果场面就成了下面这样，people mountain people sea，奏是这么有人气！","zan_num":57,"msgid":"81720","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/feeccfbda1a9279fc2b0e17cf48afe76.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/dda662839316f55d5e21ab550f27f73d.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7139839a87c67a52515e6953c7fbf5bd.jpg@w_500,h_500,o_1"}],"rtime":1486720506,"share_num":1,"ctime":1486720015,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e8921620b1c8d9bda6330246bb83d7de.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e8921620b1c8d9bda6330246bb83d7de.jpg","userid":"2698337969","username":"企鹅老大"},"comment_num":0,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":113333032,"tinguid":1325,"content_type":0,"artist_name":"大张伟","status":0,"title":"倍儿爽（官方正式版）","pic":"http://musicdata.baidu.com/data2/pic/124001022/124001022.jpg@s_0,w_90","artist_id":"570"},"msg_users":[],"is_sync":0,"msg":"最热美剧又有新进展啦！美利坚新总统川普(推特治国第一人)表示尊重\u201c一个中国\u201d政策，目前\u201cOne China（一个中国）\u201d已登上推特热门趋势，新闻狂刷不停\u2026看来美帝人民起床又要开始补习了。","zan_num":9,"msgid":"81657","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/3e5006b0b8d3c64d6609c3cc097907c5.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c6e0e89ccf6ceb2d0c2e2e5ea611893e.jpg@w_500,h_500,o_1"}],"rtime":1486718913,"share_num":1,"ctime":1486718084,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0898e7bde0e85b3af05d6994785f703c.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/0898e7bde0e85b3af05d6994785f703c.jpg","userid":"2698337923","username":"看不惯我就来打我啊"},"comment_num":2,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":13685391,"tinguid":172072,"content_type":0,"artist_name":"Adele","status":0,"title":"Rolling In The Deep","pic":"http://musicdata.baidu.com/data2/pic/89079485/89079485.jpg@s_0,w_90","artist_id":"1497"},"msg_users":[],"is_sync":0,"msg":"滚石Rolling Stone官网对本届格莱美做出了最后预测，把奖项分成了会得奖和应该得奖两种结果，并附加了应该获得提名的选项，对滚石的预测你同意嘛？\n年度专辑：会得奖「25」，应该得奖「Lemonade」，应该提名「Anti」\n年度歌曲：会得奖「Hello」，应该得奖「Hello」，应该提名「Humble and Kind」\n年度制作：会得奖「Formation」，应该得奖「Formation」，应该提名「One Dance」\n最佳新人：会得奖「The Chainsmokers」，应该得奖「Chance the Rapper」，应该提名「KING」","zan_num":7,"msgid":"81613","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/20c222da82f9e07404f57a391254a9f5.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a4a148045ad6843c75082e31668f7519.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/403914f56203a7b8e084c236527a90b6.jpg@w_500,h_500,o_1"}],"rtime":1486716369,"share_num":5,"ctime":1486716352,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2b7dfc17fb89538e32513b9365389d31.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/2b7dfc17fb89538e32513b9365389d31.jpg","userid":"2698337905","username":"土婆的老怪兽"},"comment_num":3,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":257433945,"tinguid":9319,"content_type":0,"artist_name":"Taylor Swift,Ed Sheeran","status":0,"title":"Everything Has Changed","pic":"http://musicdata.baidu.com/data2/pic/f844149f4a0ba4a6a7e74243609567de/257040420/257040420.jpg@s_0,w_90","artist_id":"816"},"msg_users":[],"is_sync":0,"msg":"每个艺人发新歌前都非常怕遭遇提前泄露，黄老板Ed Sheeran就透露了好闺蜜霉霉Taylor Swift是如何防止自己的新歌提前泄露的[激动]  剧黄老板说，霉霉绝不会把新歌（音频）发给任何人。当时他和霉霉为专辑制作歌曲，他们团队就只能飞到旧金山，在一个锁好的公文包里面有个iPad，上面就只有一首霉霉的歌，然后霉霉当着他们的面放着听，听完还问了黄老板好不好听，Ed表示当然好听啊，然后就把公文包带回去了\u2026\u2026 带回去了......[尴尬]","zan_num":4,"msgid":"81559","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b7a802e05a0a5420f5eaca2f81aeb6cb.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/a8ec03661d7a88a6e4628b2e70a3098c.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6368cd9bd8163b8ac22957498c0b826a.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/43755b9695b5f4493acad4a6293c025d.jpg@w_500,h_500,o_1"}],"rtime":1486713381,"share_num":3,"ctime":1486713132,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/9a92bc4b3557db2302b70987179e747f.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/9a92bc4b3557db2302b70987179e747f.jpg","userid":"2698337798","username":"人字健人"},"comment_num":3,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":1037883,"tinguid":6792,"content_type":0,"artist_name":"Lady Gaga","status":0,"title":"Just Dance","pic":"http://musicdata.baidu.com/data2/pic/88420023/88420023.jpg@s_0,w_90","artist_id":"1714"},"msg_users":[],"is_sync":0,"msg":"根据People和US weekly报道，Lady gaga正在与一名经纪人交往，这个经纪人叫做Christian Carino，这个人不但在超级碗那天拍到与gaga亲密拥抱，还带gaga去了Tommy Hilfiger的时装秀（他与设计师Tommy Hilfiger是很好的朋友），这名经纪人有一个女儿，曾经和许多大牌艺人合作过，也主导过很多大项目，是很厉害的经纪人。不过gaga方面还没有给出明确回应。。。你们怎么看","zan_num":7,"msgid":"81465","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e58c22a3c348685280d03a7db89db42b.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/91b9f16e93749fe3b1951e28d0c767a1.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4313a79b4c734ffc08dc9c7b70034474.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/88ec22400eddab6d2caaf952006cdd46.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/6a7bcf7639610129f84a70af366e1f6a.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/134c0518891122f8d107f387c4cf6def.jpg@w_500,h_500,o_1"}],"rtime":1486712446,"share_num":3,"ctime":1486711294,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e8921620b1c8d9bda6330246bb83d7de.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/e8921620b1c8d9bda6330246bb83d7de.jpg","userid":"2698337969","username":"企鹅老大"},"comment_num":2,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":8884267,"tinguid":718452,"content_type":0,"artist_name":"Sophie Zelmani","status":0,"title":"Going Home","pic":"http://musicdata.baidu.com/data2/music/8007E09360321962AF3DADF30B1E138F/252511080/252511080.jpg@s_0,w_90","artist_id":"45937"},"msg_users":[],"is_sync":0,"msg":"浪漫的雨中城市丨俄罗斯摄影师Eduard Gordeev。\n如果我们都有捕捉美的一瞬的灵感，任何天气都不算糟糕。","zan_num":17,"msgid":"81405","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/c9c76370bd4c589391e6eb5ff1be49c7.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fc3adf60ee2c50e81848c20deb2d5439.jpg@w_500,h_500,o_1"}],"rtime":1486707579,"share_num":4,"ctime":1486707564,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","userid":"2698311496","username":"乐坛大湿兄"},"comment_num":1,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":533295962,"tinguid":1032,"content_type":0,"artist_name":"尚雯婕","status":0,"title":"花开乱世 Blossom in Shanghai","pic":"http://musicdata.baidu.com/data2/pic/4f6b9a82d14cca88a55cf58bcde54847/533295878/533295878.jpg@s_0,w_90","artist_id":"9"},"msg_users":[],"is_sync":0,"msg":"\u201c电子唱作人\u201d尚雯婕受邀献唱著名导演胡雪桦电影作品《上海王》主题曲《花开乱世 Blossom in Shanghai》，歌曲以大气恢弘的交响乐编制，将情义背后的杀戮、黑暗、欲望、纷争娓娓道来，加之尚雯婕独具质感的音色，渲染出一个独一无二的时代传奇故事。值得一提的是，尚雯婕此次以超越流行歌手演唱技巧的高音献唱，以高难度唱法诠释了影片中时代变革背后暗藏的汹涌潮流。","zan_num":9,"msgid":"81291","status":0},{"msg_parent_id":"0","piclist":[{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/7262139790ddec10af7e0908f31fa8cf.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/b04d7c3bf48beab42909b9bf6336cdd1.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/06c91b5e7dcaf4810e9683185aa87561.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/4be747a5f4d67ef5f2a2a8d60befc06b.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/82c0ce8c006959f466ee3771df0bd325.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/da586c58bf763e5dc39c4cd7f730cc28.jpg@w_500,h_500,o_1"}],"rtime":1486701956,"share_num":6,"ctime":1486701936,"author":{"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/414fa99f775619297d2b0be9839fe32d.jpg","flag":"000","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/414fa99f775619297d2b0be9839fe32d.jpg","userid":"2698337648","username":"爱听黑炮的兔子哥"},"comment_num":1,"isAuthor":0,"specFlag":1,"islike":0,"zan_list":[],"msgtype":1,"isFriend":0,"content":{"content_id":525747,"tinguid":11703,"content_type":0,"artist_name":"Rihanna","status":0,"title":"Te Amo","pic":"http://musicdata.baidu.com/data2/music/5F5D3D6C3E8270CDC4E0896E5A5FA5A1/252858002/252858002.jpg@s_0,w_90","artist_id":"809"},"msg_users":[],"is_sync":0,"msg":"辣眼睛[尴尬] 一名同志网站编辑Anthony Gilét拍摄全新写真致敬女星历年经典写真，致敬明星包括布兰妮、麦当娜、Beyonce、Rihanna、Mariah Care等人...","zan_num":15,"msgid":"81098","status":0}]
     * last_timestamp : 1486701956
     * is_guide : 1
     * topics : [{"pic_750x215":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg@w_750,h_215,o_1","pic_50x50":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@o_1|s_2,w_50,h_50","pic_350x170":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_350,h_170,o_1","editor":"yangdini","attr":"a:6:{s:11:\"topic_title\";s:37:\"送出你2017年的新春祝福吧！\";s:4:\"desc\";s:225:\"鸡鸣晓日江山丽，犬吠神州岁月新！百度音乐在此祝大家鸡年大吉！万事如意！新的一年，你最想给谁送出你的新春祝福呢？快来参加我们的话题，送出你的新春祝福吧！\";s:8:\"userlist\";s:0:\"\";s:6:\"editor\";s:8:\"yangdini\";s:3:\"pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg\";s:7:\"min_pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg\";}","topic_title":"送出你2017年的新春祝福吧！","ctime":1485393567,"is_recommend":1,"topic_id":"1061","pic_980x280":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg@w_980,h_280,o_1","pic_min":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg","mod_state":0,"desc":"鸡鸣晓日江山丽，犬吠神州岁月新！百度音乐在此祝大家鸡年大吉！万事如意！新的一年，你最想给谁送出你的新春祝福呢？快来参加我们的话题，送出你的新春祝福吧！","pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg","pic_700x340":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_700,h_340,o_1","min_pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg","usertype":1,"pic_180x88":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_180,h_88,o_1","nums":319,"status":0},{"pic_750x215":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1484029282b2b1665150f5a860ff3e253fd26f003d.jpg@w_750,h_215,o_1","pic_50x50":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg@o_1|s_2,w_50,h_50","pic_350x170":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg@w_350,h_170,o_1","editor":"houyue","attr":"a:8:{s:11:\"topic_title\";s:39:\"你最喜欢的专辑封面长啥样？\";s:4:\"desc\";s:136:\"对于喜欢听音乐的朋友们来说,欣赏专辑的封面也是一大乐趣！不妨一起来晒出你最喜欢的专辑封面吧！\";s:8:\"userlist\";s:0:\"\";s:3:\"pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1484029282b2b1665150f5a860ff3e253fd26f003d.jpg\";s:7:\"min_pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg\";s:6:\"status\";i:0;s:6:\"editor\";s:6:\"houyue\";s:5:\"ctime\";s:10:\"1484029469\";}","topic_title":"你最喜欢的专辑封面长啥样？","ctime":1484029469,"is_recommend":1,"topic_id":"937","pic_980x280":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1484029282b2b1665150f5a860ff3e253fd26f003d.jpg@w_980,h_280,o_1","pic_min":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg","mod_state":0,"desc":"对于喜欢听音乐的朋友们来说,欣赏专辑的封面也是一大乐趣！不妨一起来晒出你最喜欢的专辑封面吧！","pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1484029282b2b1665150f5a860ff3e253fd26f003d.jpg","pic_700x340":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg@w_700,h_340,o_1","min_pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg","usertype":1,"pic_180x88":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14840292893c6cd151a95704ea2e1381a05fa10bb0.jpg@w_180,h_88,o_1","nums":291,"status":0},{"pic_750x215":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14748597274d18d26392ede2361a141cb3af39366a.jpg@w_750,h_215,o_1","pic_50x50":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg@o_1|s_2,w_50,h_50","pic_350x170":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg@w_350,h_170,o_1","editor":"liqixing","attr":"a:8:{s:11:\"topic_title\";s:42:\"你单曲循环最多的是哪一首歌？\";s:4:\"desc\";s:175:\"不经意间，我们就会被一首陌生的歌惊艳，上瘾中毒，反复聆听。你有没有这样的经历？哪首歌曾让你止不住的循环呢？快来分享吧~\";s:8:\"userlist\";s:0:\"\";s:3:\"pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_14748597274d18d26392ede2361a141cb3af39366a.jpg\";s:7:\"min_pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg\";s:6:\"status\";i:0;s:6:\"editor\";s:8:\"liqixing\";s:5:\"ctime\";s:10:\"1474859731\";}","topic_title":"你单曲循环最多的是哪一首歌？","ctime":1474859731,"is_recommend":1,"topic_id":"89","pic_980x280":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14748597274d18d26392ede2361a141cb3af39366a.jpg@w_980,h_280,o_1","pic_min":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg","mod_state":0,"desc":"不经意间，我们就会被一首陌生的歌惊艳，上瘾中毒，反复聆听。你有没有这样的经历？哪首歌曾让你止不住的循环呢？快来分享吧~","pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_14748597274d18d26392ede2361a141cb3af39366a.jpg","pic_700x340":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg@w_700,h_340,o_1","min_pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg","usertype":1,"pic_180x88":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1474859729ad96ce7df4f0b6d820c906f50a8822fe.jpg@w_180,h_88,o_1","nums":3691,"status":0}]
     * error_code : 22000
     * last_msg_id : 81098
     */

    private int new_msg_num;
    private String last_timestamp;
    private int is_guide;
    private int error_code;
    private String last_msg_id;
    private List<MsgBean> msg;
    private List<TopicsBean> topics;

    public int getNew_msg_num() {
        return new_msg_num;
    }

    public void setNew_msg_num(int new_msg_num) {
        this.new_msg_num = new_msg_num;
    }

    public String getLast_timestamp() {
        return last_timestamp;
    }

    public void setLast_timestamp(String last_timestamp) {
        this.last_timestamp = last_timestamp;
    }

    public int getIs_guide() {
        return is_guide;
    }

    public void setIs_guide(int is_guide) {
        this.is_guide = is_guide;
    }

    public int getError_code() {
        return error_code;
    }

    public void setError_code(int error_code) {
        this.error_code = error_code;
    }

    public String getLast_msg_id() {
        return last_msg_id;
    }

    public void setLast_msg_id(String last_msg_id) {
        this.last_msg_id = last_msg_id;
    }

    public List<MsgBean> getMsg() {
        return msg;
    }

    public void setMsg(List<MsgBean> msg) {
        this.msg = msg;
    }

    public List<TopicsBean> getTopics() {
        return topics;
    }

    public void setTopics(List<TopicsBean> topics) {
        this.topics = topics;
    }

    public static class MsgBean {
        /**
         * msg_parent_id : 0
         * piclist : [{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_500,h_500,o_1"},{"pic_large":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_360,h_192","master":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg","pic_middle":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_294,h_192","pic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@o_1|s_2,w_192,h_192","pic_360":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@w_360,o_1","thumbnail":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/8c3732dbb5d81567c0e1a778663aea65.jpg@w_500,h_500,o_1"}]
         * rtime : 1486782859
         * share_num : 0
         * ctime : 1486782805
         * author : {"userpic":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","flag":"010","userpic_small":"http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg","userid":"2698311496","username":"乐坛大湿兄"}
         * comment_num : 0
         * isAuthor : 0
         * specFlag : 1
         * islike : 0
         * zan_list : []
         * msgtype : 1
         * isFriend : 0
         * content : {"content_id":315705707,"tinguid":2716,"content_type":0,"artist_name":"Katy Perry,Skip Marley","status":0,"title":"Chained To The Rhythm","pic":"http://musicdata.baidu.com/data2/pic/21c926ccadebf7156689961ac234393c/315705698/315705698.jpg@s_0,w_90","artist_id":"1512"}
         * msg_users : []
         * is_sync : 0
         * msg : Katy Perry水果姐带着新单强势回归！[花心][花心]此次Katy Perry 联手Skip Marley 推出新单《Chained to the Rhythm》，新曲由洗牙姐Sia和冠单制造机Max Martin参与填词，浓浓的复古迪斯科风炒鸡赞，期待这次再次夺冠！来跟着the Rhythm一起摇摆吧！
         * zan_num : 0
         * msgid : 83064
         * status : 0
         * topic : {"pic_750x215":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_750,h_215,o_1","pic_50x50":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@o_1|s_2,w_50,h_50","pic_350x170":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_350,h_170,o_1","editor":"houyue","attr":"a:8:{s:11:\"topic_title\";s:39:\"今年春节你妈逼你结婚了吗？\";s:4:\"desc\";s:297:\"历年来过年回家被三姑六婆问得最多的问题就是：\u201c孩子，有对象了吗？啥时候结婚啊？\u2026\u201d今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的\u201c攻略\u201d吧！\";s:8:\"userlist\";s:0:\"\";s:3:\"pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg\";s:7:\"min_pic\";s:98:\"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg\";s:6:\"status\";i:0;s:6:\"editor\";s:6:\"houyue\";s:5:\"ctime\";s:10:\"1485923015\";}","topic_title":"今年春节你妈逼你结婚了吗？","ctime":1485923015,"is_recommend":1,"topic_id":"1098","pic_980x280":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_980,h_280,o_1","pic_min":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg","mod_state":0,"desc":"历年来过年回家被三姑六婆问得最多的问题就是：\u201c孩子，有对象了吗？啥时候结婚啊？\u2026\u201d今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的\u201c攻略\u201d吧！","pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg","pic_700x340":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_700,h_340,o_1","min_pic":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg","usertype":1,"pic_180x88":"http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_180,h_88,o_1","nums":149,"status":0}
         */

        private String msg_parent_id;
        private int rtime;
        private int share_num;
        private int ctime;
        private AuthorBean author;
        private int comment_num;
        private int isAuthor;
        private int specFlag;
        private int islike;
        private int msgtype;
        private int isFriend;
        private ContentBean content;
        private int is_sync;
        private String msg;
        private int zan_num;
        private String msgid;
        private int status;
        private TopicBean topic;
        private List<PiclistBean> piclist;
        private List<?> zan_list;
        private List<?> msg_users;

        public String getMsg_parent_id() {
            return msg_parent_id;
        }

        public void setMsg_parent_id(String msg_parent_id) {
            this.msg_parent_id = msg_parent_id;
        }

        public int getRtime() {
            return rtime;
        }

        public void setRtime(int rtime) {
            this.rtime = rtime;
        }

        public int getShare_num() {
            return share_num;
        }

        public void setShare_num(int share_num) {
            this.share_num = share_num;
        }

        public int getCtime() {
            return ctime;
        }

        public void setCtime(int ctime) {
            this.ctime = ctime;
        }

        public AuthorBean getAuthor() {
            return author;
        }

        public void setAuthor(AuthorBean author) {
            this.author = author;
        }

        public int getComment_num() {
            return comment_num;
        }

        public void setComment_num(int comment_num) {
            this.comment_num = comment_num;
        }

        public int getIsAuthor() {
            return isAuthor;
        }

        public void setIsAuthor(int isAuthor) {
            this.isAuthor = isAuthor;
        }

        public int getSpecFlag() {
            return specFlag;
        }

        public void setSpecFlag(int specFlag) {
            this.specFlag = specFlag;
        }

        public int getIslike() {
            return islike;
        }

        public void setIslike(int islike) {
            this.islike = islike;
        }

        public int getMsgtype() {
            return msgtype;
        }

        public void setMsgtype(int msgtype) {
            this.msgtype = msgtype;
        }

        public int getIsFriend() {
            return isFriend;
        }

        public void setIsFriend(int isFriend) {
            this.isFriend = isFriend;
        }

        public ContentBean getContent() {
            return content;
        }

        public void setContent(ContentBean content) {
            this.content = content;
        }

        public int getIs_sync() {
            return is_sync;
        }

        public void setIs_sync(int is_sync) {
            this.is_sync = is_sync;
        }

        public String getMsg() {
            return msg;
        }

        public void setMsg(String msg) {
            this.msg = msg;
        }

        public int getZan_num() {
            return zan_num;
        }

        public void setZan_num(int zan_num) {
            this.zan_num = zan_num;
        }

        public String getMsgid() {
            return msgid;
        }

        public void setMsgid(String msgid) {
            this.msgid = msgid;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public TopicBean getTopic() {
            return topic;
        }

        public void setTopic(TopicBean topic) {
            this.topic = topic;
        }

        public List<PiclistBean> getPiclist() {
            return piclist;
        }

        public void setPiclist(List<PiclistBean> piclist) {
            this.piclist = piclist;
        }

        public List<?> getZan_list() {
            return zan_list;
        }

        public void setZan_list(List<?> zan_list) {
            this.zan_list = zan_list;
        }

        public List<?> getMsg_users() {
            return msg_users;
        }

        public void setMsg_users(List<?> msg_users) {
            this.msg_users = msg_users;
        }

        public static class AuthorBean {
            /**
             * userpic : http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg
             * flag : 010
             * userpic_small : http://musicugc.cdn.qianqian.com/ugcdiy/pic/249de8d228cf158e22f5278fea15e098.jpg
             * userid : 2698311496
             * username : 乐坛大湿兄
             */

            private String userpic;
            private String flag;
            private String userpic_small;
            private String userid;
            private String username;

            public String getUserpic() {
                return userpic;
            }

            public void setUserpic(String userpic) {
                this.userpic = userpic;
            }

            public String getFlag() {
                return flag;
            }

            public void setFlag(String flag) {
                this.flag = flag;
            }

            public String getUserpic_small() {
                return userpic_small;
            }

            public void setUserpic_small(String userpic_small) {
                this.userpic_small = userpic_small;
            }

            public String getUserid() {
                return userid;
            }

            public void setUserid(String userid) {
                this.userid = userid;
            }

            public String getUsername() {
                return username;
            }

            public void setUsername(String username) {
                this.username = username;
            }
        }

        public static class ContentBean {
            /**
             * content_id : 315705707
             * tinguid : 2716
             * content_type : 0
             * artist_name : Katy Perry,Skip Marley
             * status : 0
             * title : Chained To The Rhythm
             * pic : http://musicdata.baidu.com/data2/pic/21c926ccadebf7156689961ac234393c/315705698/315705698.jpg@s_0,w_90
             * artist_id : 1512
             */

            private int content_id;
            private int tinguid;
            private int content_type;
            private String artist_name;
            private int status;
            private String title;
            private String pic;
            private String artist_id;

            public int getContent_id() {
                return content_id;
            }

            public void setContent_id(int content_id) {
                this.content_id = content_id;
            }

            public int getTinguid() {
                return tinguid;
            }

            public void setTinguid(int tinguid) {
                this.tinguid = tinguid;
            }

            public int getContent_type() {
                return content_type;
            }

            public void setContent_type(int content_type) {
                this.content_type = content_type;
            }

            public String getArtist_name() {
                return artist_name;
            }

            public void setArtist_name(String artist_name) {
                this.artist_name = artist_name;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }

            public String getTitle() {
                return title;
            }

            public void setTitle(String title) {
                this.title = title;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getArtist_id() {
                return artist_id;
            }

            public void setArtist_id(String artist_id) {
                this.artist_id = artist_id;
            }
        }

        public static class TopicBean {
            /**
             * pic_750x215 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_750,h_215,o_1
             * pic_50x50 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@o_1|s_2,w_50,h_50
             * pic_350x170 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_350,h_170,o_1
             * editor : houyue
             * attr : a:8:{s:11:"topic_title";s:39:"今年春节你妈逼你结婚了吗？";s:4:"desc";s:297:"历年来过年回家被三姑六婆问得最多的问题就是：“孩子，有对象了吗？啥时候结婚啊？…”今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的“攻略”吧！";s:8:"userlist";s:0:"";s:3:"pic";s:98:"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg";s:7:"min_pic";s:98:"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg";s:6:"status";i:0;s:6:"editor";s:6:"houyue";s:5:"ctime";s:10:"1485923015";}
             * topic_title : 今年春节你妈逼你结婚了吗？
             * ctime : 1485923015
             * is_recommend : 1
             * topic_id : 1098
             * pic_980x280 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg@w_980,h_280,o_1
             * pic_min : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg
             * mod_state : 0
             * desc : 历年来过年回家被三姑六婆问得最多的问题就是：“孩子，有对象了吗？啥时候结婚啊？…”今年春节你是不是又中招了呢？面对这个问题应该如何机智地回答，求你支个招！快来参加话题，和大家一起分享你的“攻略”吧！
             * pic : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922967066481b664bf9f12e6f041208615060d.jpg
             * pic_700x340 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_700,h_340,o_1
             * min_pic : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg
             * usertype : 1
             * pic_180x88 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485922974dc948a60d7013fd1fc86b2fd778be1be.jpg@w_180,h_88,o_1
             * nums : 149
             * status : 0
             */

            private String pic_750x215;
            private String pic_50x50;
            private String pic_350x170;
            private String editor;
            private String attr;
            private String topic_title;
            private int ctime;
            private int is_recommend;
            private String topic_id;
            private String pic_980x280;
            private String pic_min;
            private int mod_state;
            private String desc;
            private String pic;
            private String pic_700x340;
            private String min_pic;
            private int usertype;
            private String pic_180x88;
            private int nums;
            private int status;

            public String getPic_750x215() {
                return pic_750x215;
            }

            public void setPic_750x215(String pic_750x215) {
                this.pic_750x215 = pic_750x215;
            }

            public String getPic_50x50() {
                return pic_50x50;
            }

            public void setPic_50x50(String pic_50x50) {
                this.pic_50x50 = pic_50x50;
            }

            public String getPic_350x170() {
                return pic_350x170;
            }

            public void setPic_350x170(String pic_350x170) {
                this.pic_350x170 = pic_350x170;
            }

            public String getEditor() {
                return editor;
            }

            public void setEditor(String editor) {
                this.editor = editor;
            }

            public String getAttr() {
                return attr;
            }

            public void setAttr(String attr) {
                this.attr = attr;
            }

            public String getTopic_title() {
                return topic_title;
            }

            public void setTopic_title(String topic_title) {
                this.topic_title = topic_title;
            }

            public int getCtime() {
                return ctime;
            }

            public void setCtime(int ctime) {
                this.ctime = ctime;
            }

            public int getIs_recommend() {
                return is_recommend;
            }

            public void setIs_recommend(int is_recommend) {
                this.is_recommend = is_recommend;
            }

            public String getTopic_id() {
                return topic_id;
            }

            public void setTopic_id(String topic_id) {
                this.topic_id = topic_id;
            }

            public String getPic_980x280() {
                return pic_980x280;
            }

            public void setPic_980x280(String pic_980x280) {
                this.pic_980x280 = pic_980x280;
            }

            public String getPic_min() {
                return pic_min;
            }

            public void setPic_min(String pic_min) {
                this.pic_min = pic_min;
            }

            public int getMod_state() {
                return mod_state;
            }

            public void setMod_state(int mod_state) {
                this.mod_state = mod_state;
            }

            public String getDesc() {
                return desc;
            }

            public void setDesc(String desc) {
                this.desc = desc;
            }

            public String getPic() {
                return pic;
            }

            public void setPic(String pic) {
                this.pic = pic;
            }

            public String getPic_700x340() {
                return pic_700x340;
            }

            public void setPic_700x340(String pic_700x340) {
                this.pic_700x340 = pic_700x340;
            }

            public String getMin_pic() {
                return min_pic;
            }

            public void setMin_pic(String min_pic) {
                this.min_pic = min_pic;
            }

            public int getUsertype() {
                return usertype;
            }

            public void setUsertype(int usertype) {
                this.usertype = usertype;
            }

            public String getPic_180x88() {
                return pic_180x88;
            }

            public void setPic_180x88(String pic_180x88) {
                this.pic_180x88 = pic_180x88;
            }

            public int getNums() {
                return nums;
            }

            public void setNums(int nums) {
                this.nums = nums;
            }

            public int getStatus() {
                return status;
            }

            public void setStatus(int status) {
                this.status = status;
            }
        }

        public static class PiclistBean {
            /**
             * pic_large : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_360,h_192
             * master : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg
             * pic_middle : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_294,h_192
             * pic_small : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@o_1|s_2,w_192,h_192
             * pic_360 : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_360,o_1
             * thumbnail : http://musicugc.cdn.qianqian.com/ugcdiy/pic/fe7cedfa78d7383cb0d95c0e5d8c28fb.jpg@w_500,h_500,o_1
             */

            private String pic_large;
            private String master;
            private String pic_middle;
            private String pic_small;
            private String pic_360;
            private String thumbnail;

            public String getPic_large() {
                return pic_large;
            }

            public void setPic_large(String pic_large) {
                this.pic_large = pic_large;
            }

            public String getMaster() {
                return master;
            }

            public void setMaster(String master) {
                this.master = master;
            }

            public String getPic_middle() {
                return pic_middle;
            }

            public void setPic_middle(String pic_middle) {
                this.pic_middle = pic_middle;
            }

            public String getPic_small() {
                return pic_small;
            }

            public void setPic_small(String pic_small) {
                this.pic_small = pic_small;
            }

            public String getPic_360() {
                return pic_360;
            }

            public void setPic_360(String pic_360) {
                this.pic_360 = pic_360;
            }

            public String getThumbnail() {
                return thumbnail;
            }

            public void setThumbnail(String thumbnail) {
                this.thumbnail = thumbnail;
            }
        }
    }

    public static class TopicsBean {
        /**
         * pic_750x215 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg@w_750,h_215,o_1
         * pic_50x50 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@o_1|s_2,w_50,h_50
         * pic_350x170 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_350,h_170,o_1
         * editor : yangdini
         * attr : a:6:{s:11:"topic_title";s:37:"送出你2017年的新春祝福吧！";s:4:"desc";s:225:"鸡鸣晓日江山丽，犬吠神州岁月新！百度音乐在此祝大家鸡年大吉！万事如意！新的一年，你最想给谁送出你的新春祝福呢？快来参加我们的话题，送出你的新春祝福吧！";s:8:"userlist";s:0:"";s:6:"editor";s:8:"yangdini";s:3:"pic";s:98:"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg";s:7:"min_pic";s:98:"http://bj.bcebos.com/relay/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg";}
         * topic_title : 送出你2017年的新春祝福吧！
         * ctime : 1485393567
         * is_recommend : 1
         * topic_id : 1061
         * pic_980x280 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg@w_980,h_280,o_1
         * pic_min : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg
         * mod_state : 0
         * desc : 鸡鸣晓日江山丽，犬吠神州岁月新！百度音乐在此祝大家鸡年大吉！万事如意！新的一年，你最想给谁送出你的新春祝福呢？快来参加我们的话题，送出你的新春祝福吧！
         * pic : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393550e804167f3ec6b1b9715c82d35214f3c4.jpg
         * pic_700x340 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_700,h_340,o_1
         * min_pic : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg
         * usertype : 1
         * pic_180x88 : http://ugcpic.qianqian.com/ugcdiy/pic/bos_ugcclient_1485393560f2bf36284473f675a918328b64a67ef0.jpg@w_180,h_88,o_1
         * nums : 319
         * status : 0
         */

        private String pic_750x215;
        private String pic_50x50;
        private String pic_350x170;
        private String editor;
        private String attr;
        private String topic_title;
        private int ctime;
        private int is_recommend;
        private String topic_id;
        private String pic_980x280;
        private String pic_min;
        private int mod_state;
        private String desc;
        private String pic;
        private String pic_700x340;
        private String min_pic;
        private int usertype;
        private String pic_180x88;
        private int nums;
        private int status;

        public String getPic_750x215() {
            return pic_750x215;
        }

        public void setPic_750x215(String pic_750x215) {
            this.pic_750x215 = pic_750x215;
        }

        public String getPic_50x50() {
            return pic_50x50;
        }

        public void setPic_50x50(String pic_50x50) {
            this.pic_50x50 = pic_50x50;
        }

        public String getPic_350x170() {
            return pic_350x170;
        }

        public void setPic_350x170(String pic_350x170) {
            this.pic_350x170 = pic_350x170;
        }

        public String getEditor() {
            return editor;
        }

        public void setEditor(String editor) {
            this.editor = editor;
        }

        public String getAttr() {
            return attr;
        }

        public void setAttr(String attr) {
            this.attr = attr;
        }

        public String getTopic_title() {
            return topic_title;
        }

        public void setTopic_title(String topic_title) {
            this.topic_title = topic_title;
        }

        public int getCtime() {
            return ctime;
        }

        public void setCtime(int ctime) {
            this.ctime = ctime;
        }

        public int getIs_recommend() {
            return is_recommend;
        }

        public void setIs_recommend(int is_recommend) {
            this.is_recommend = is_recommend;
        }

        public String getTopic_id() {
            return topic_id;
        }

        public void setTopic_id(String topic_id) {
            this.topic_id = topic_id;
        }

        public String getPic_980x280() {
            return pic_980x280;
        }

        public void setPic_980x280(String pic_980x280) {
            this.pic_980x280 = pic_980x280;
        }

        public String getPic_min() {
            return pic_min;
        }

        public void setPic_min(String pic_min) {
            this.pic_min = pic_min;
        }

        public int getMod_state() {
            return mod_state;
        }

        public void setMod_state(int mod_state) {
            this.mod_state = mod_state;
        }

        public String getDesc() {
            return desc;
        }

        public void setDesc(String desc) {
            this.desc = desc;
        }

        public String getPic() {
            return pic;
        }

        public void setPic(String pic) {
            this.pic = pic;
        }

        public String getPic_700x340() {
            return pic_700x340;
        }

        public void setPic_700x340(String pic_700x340) {
            this.pic_700x340 = pic_700x340;
        }

        public String getMin_pic() {
            return min_pic;
        }

        public void setMin_pic(String min_pic) {
            this.min_pic = min_pic;
        }

        public int getUsertype() {
            return usertype;
        }

        public void setUsertype(int usertype) {
            this.usertype = usertype;
        }

        public String getPic_180x88() {
            return pic_180x88;
        }

        public void setPic_180x88(String pic_180x88) {
            this.pic_180x88 = pic_180x88;
        }

        public int getNums() {
            return nums;
        }

        public void setNums(int nums) {
            this.nums = nums;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }
    }
}
